<?php
declare(strict_types=1);

namespace Martello\Repositories;

use Martello\Core\JsonDataStore;
use RuntimeException;

class AuctionRepository
{
    public function __construct(private JsonDataStore $store) {}

    public function findLotById(array &$dbData, int $lotId): ?array
    {
        foreach ($dbData['lots'] as $lot) {
            if ((int) $lot['id'] === $lotId) {
                return $lot;
            }
        }
        return null;
    }

    public function updateLot(array &$dbData, array $updatedLot): void
    {
        foreach ($dbData['lots'] as $index => $lot) {
            if ((int) $lot['id'] === (int) $updatedLot['id']) {
                $dbData['lots'][$index] = $updatedLot;
                return;
            }
        }
        throw new RuntimeException("Güncellenecek Lot bulunamadı: #{$updatedLot['id']}");
    }

    public function findHighestValidBidForLot(array &$dbData, int $lotId): ?array
    {
        $validBids = array_filter(
            $dbData['bids'] ?? [],
            static fn(array $b): bool => (int) $b['lotId'] === $lotId && $b['durum'] === 'GECERLI'
        );
        if (empty($validBids)) {
            return null;
        }
        usort($validBids, static fn(array $a, array $b): int => $b['teklifTutari'] <=> $a['teklifTutari']);
        return $validBids[0];
    }

    public function insertBid(array &$dbData, array $newBid): array
    {
        $dbData['bids'][] = $newBid;
        return $newBid;
    }

    public function findHighestActiveProxyBid(array &$dbData, int $lotId, int $excludeBuyerId): ?array
    {
        $candidates = array_filter(
            $dbData['proxyBids'] ?? [],
            static fn(array $p): bool =>
                (int) $p['lotId'] === $lotId &&
                (bool) $p['aktifMi'] === true &&
                (int) $p['aliciId'] !== $excludeBuyerId
        );
        if (empty($candidates)) {
            return null;
        }
        usort($candidates, static fn(array $a, array $b): int => $b['maksimumButceTutari'] <=> $a['maksimumButceTutari']);
        return $candidates[0];
    }
}
