<?php
declare(strict_types=1);

namespace Martello\Services;

use Martello\Core\JsonDataStore;
use Martello\Middlewares\SecurityAndMaskingMiddleware;
use Martello\Patterns\Observer\AuctionSubject;
use Martello\Patterns\Strategy\Bidding\IBiddingRuleStrategy;
use Martello\Patterns\Strategy\Commission\ArtAntiqueCommission;
use Martello\Patterns\Strategy\Payment\IPaymentStrategy;
use Martello\Repositories\AuctionRepository;
use RuntimeException;

/**
 * 3. Katman: Çekirdek Müzayede, Pey, Proxy Bidding ve Anti-Sniping Servisi
 */
class AuctionEngineService
{
    public function __construct(
        private JsonDataStore $store,
        private AuctionRepository $auctionRepo,
        private IBiddingRuleStrategy $biddingStrategy,
        private IPaymentStrategy $paymentStrategy,
        private AuctionSubject $auctionSubject
    ) {}

    public function placeBid(int $lotId, int $buyerId, float $bidAmount, string $ipAddress = '127.0.0.1'): array
    {
        return $this->store->executeTransaction("lot_{$lotId}", function (array &$dbData) use ($lotId, $buyerId, $bidAmount, $ipAddress): array {
            $lot = $this->auctionRepo->findLotById($dbData, $lotId);
            if ($lot === null) {
                throw new RuntimeException("Lot bulunamadı: #{$lotId}");
            }

            $buyer = null;
            foreach ($dbData['users'] as $u) {
                if ((int) $u['id'] === $buyerId) {
                    $buyer = $u;
                    break;
                }
            }
            if ($buyer === null) {
                throw new RuntimeException("Kullanıcı bulunamadı: #{$buyerId}");
            }

            SecurityAndMaskingMiddleware::enforceRbac($buyer, ['ALICI', 'SATICI']);

            $sellerId = 0;
            foreach ($dbData['products'] as $p) {
                if ((int) $p['id'] === (int) $lot['urunId']) {
                    $sellerId = (int) $p['saticiId'];
                    break;
                }
            }
            if ($sellerId === $buyerId) {
                throw new RuntimeException('R-04 Güvenlik Kuralı: Satıcı kendi ürününe teklif veremez (Shill Bidding Engellendi).');
            }

            $antiSnipeParams = $dbData['systemParameters']['antiSniping'] ?? [];
            $ruleResult      = $this->biddingStrategy->validateAndApplyAntiSnipe($lot, $bidAmount, time(), $antiSnipeParams);

            $previousHighestBid = $this->auctionRepo->findHighestValidBidForLot($dbData, $lotId);
            $newBidId           = count($dbData['bids']) + 9001;

            $blokeId = $this->paymentStrategy->processAndBlockFunds(
                $dbData,
                $buyerId,
                $lotId,
                $newBidId,
                $bidAmount,
                $lot['paraBirimi']
            );

            $newBid = [
                'id'             => $newBidId,
                'lotId'          => $lotId,
                'muzayedeId'     => (int) $lot['muzayedeId'],
                'aliciId'        => $buyerId,
                'aliciAnonimKod' => SecurityAndMaskingMiddleware::maskParticipantIdentity($buyer),
                'teklifTutari'   => $bidAmount,
                'paraBirimi'     => $lot['paraBirimi'],
                'teklifTipi'     => 'MANUEL',
                'teklifZamani'   => date('c'),
                'saatEtiketi'    => 'Az önce (' . date('H:i:s') . ')',
                'durum'          => 'GECERLI',
                'blokeIslemId'   => $blokeId,
            ];
            $this->auctionRepo->insertBid($dbData, $newBid);

            $lot['mevcutEnYuksekTeklif'] = $bidAmount;
            $lot['liderAliciId']         = $buyerId;
            $lot['liderAnonimKod']       = $newBid['aliciAnonimKod'];
            $this->auctionRepo->updateLot($dbData, $lot);

            $eventContext = [
                'dbData'             => &$dbData,
                'lot'                => $lot,
                'buyer'              => $buyer,
                'sellerId'           => $sellerId,
                'newBid'             => $newBid,
                'previousHighestBid' => $previousHighestBid,
                'extendedSeconds'    => $ruleResult['extendedSeconds'],
                'ipAddress'          => $ipAddress,
                'realtimeBroadcasts' => [],
            ];
            $this->auctionSubject->notifyObservers('BID_PLACED', $eventContext);

            // Bölüm 2.6.1 & NFR-24: Otomatik Teklif / Proxy Bidding Motoru
            $activeProxy       = $this->auctionRepo->findHighestActiveProxyBid($dbData, $lotId, $buyerId);
            $autoBidTriggered  = null;

            if ($activeProxy !== null) {
                $autoNextAmount = $bidAmount + (float) $lot['minimumArtisTutari'];
                if ((float) $activeProxy['maksimumButceTutari'] >= $autoNextAmount) {
                    $proxyBuyerId = (int) $activeProxy['aliciId'];
                    $proxyBuyer   = null;
                    foreach ($dbData['users'] as $u) {
                        if ((int) $u['id'] === $proxyBuyerId) {
                            $proxyBuyer = $u;
                            break;
                        }
                    }

                    if ($proxyBuyer !== null) {
                        $autoBidId   = count($dbData['bids']) + 9001;
                        $autoBlokeId = $this->paymentStrategy->processAndBlockFunds(
                            $dbData,
                            $proxyBuyerId,
                            $lotId,
                            $autoBidId,
                            $autoNextAmount,
                            $lot['paraBirimi']
                        );

                        $autoBid = [
                            'id'             => $autoBidId,
                            'lotId'          => $lotId,
                            'muzayedeId'     => (int) $lot['muzayedeId'],
                            'aliciId'        => $proxyBuyerId,
                            'aliciAnonimKod' => SecurityAndMaskingMiddleware::maskParticipantIdentity($proxyBuyer),
                            'teklifTutari'   => $autoNextAmount,
                            'paraBirimi'     => $lot['paraBirimi'],
                            'teklifTipi'     => 'OTOMATIK_PROXY',
                            'teklifZamani'   => date('c'),
                            'saatEtiketi'    => 'Otomatik Pey (' . date('H:i:s') . ')',
                            'durum'          => 'GECERLI',
                            'blokeIslemId'   => $autoBlokeId,
                        ];
                        $this->auctionRepo->insertBid($dbData, $autoBid);

                        $lot['mevcutEnYuksekTeklif'] = $autoNextAmount;
                        $lot['liderAliciId']         = $proxyBuyerId;
                        $lot['liderAnonimKod']       = $autoBid['aliciAnonimKod'];
                        $this->auctionRepo->updateLot($dbData, $lot);

                        $proxyContext = [
                            'dbData'             => &$dbData,
                            'lot'                => $lot,
                            'buyer'              => $proxyBuyer,
                            'sellerId'           => $sellerId,
                            'newBid'             => $autoBid,
                            'previousHighestBid' => $newBid,
                            'extendedSeconds'    => 0,
                            'ipAddress'          => 'SYSTEM-PROXY-ENGINE',
                            'realtimeBroadcasts' => &$eventContext['realtimeBroadcasts'],
                        ];
                        $this->auctionSubject->notifyObservers('BID_PLACED', $proxyContext);
                        $autoBidTriggered = $autoBid;
                    }
                }
            }

            return [
                'status'             => 'SUCCESS',
                'acceptedBid'        => $newBid,
                'autoProxyResponse'  => $autoBidTriggered,
                'updatedLot'         => $lot,
                'realtimeBroadcasts' => $eventContext['realtimeBroadcasts'],
            ];
        });
    }

    /**
     * Bölüm 2.6.1 & NFR-24: Otomatik Teklif (Proxy Bid) Tavan Bütçe Tanımlama
     */
    public function setProxyBid(int $lotId, int $buyerId, float $maxBudget): array
    {
        return $this->store->executeTransaction("lot_{$lotId}", function (array &$dbData) use ($lotId, $buyerId, $maxBudget): array {
            $newProxy = [
                'id'                  => count($dbData['proxyBids']) + 3001,
                'lotId'               => $lotId,
                'aliciId'             => $buyerId,
                'maksimumButceTutari' => $maxBudget,
                'paraBirimi'          => 'TRY',
                'aktifMi'             => true,
                'olusturmaZamani'     => date('c'),
            ];
            $dbData['proxyBids'][] = $newProxy;
            return $newProxy;
        });
    }

    /**
     * FR-10 & FR-29: Müzayede Lotunu Sonlandır ve Otomatik Sipariş Oluştur
     */
    public function closeLotAndCreateOrder(int $lotId): array
    {
        return $this->store->executeTransaction("lot_{$lotId}", function (array &$dbData) use ($lotId): array {
            $lot = $this->auctionRepo->findLotById($dbData, $lotId);
            if ($lot === null) {
                throw new RuntimeException("Lot bulunamadı: #{$lotId}");
            }
            $winningBid = $this->auctionRepo->findHighestValidBidForLot($dbData, $lotId);
            if ($winningBid === null || (float) $winningBid['teklifTutari'] < (float) $lot['rezervFiyat']) {
                $lot['durum'] = 'REZERV_ALTINDA_KAPANDI';
                $this->auctionRepo->updateLot($dbData, $lot);
                return ['status' => 'RESERVE_NOT_MET', 'lot' => $lot];
            }

            $lot['durum'] = 'SATILDI';
            $this->auctionRepo->updateLot($dbData, $lot);

            $commissionStrategy = new ArtAntiqueCommission();
            $breakdown          = $commissionStrategy->calculateBreakdown((float) $winningBid['teklifTutari'], ['komisyonOraniYuzde' => 8.0, 'sabitEkspertizUcreti' => 1500.0]);

            $context = [
                'dbData'              => &$dbData,
                'lot'                 => $lot,
                'winningBid'          => $winningBid,
                'sellerId'            => 2,
                'commissionBreakdown' => $breakdown,
            ];
            $this->auctionSubject->notifyObservers('AUCTION_CLOSED', $context);

            return ['status' => 'SOLD_AND_ORDER_CREATED', 'lot' => $lot, 'breakdown' => $breakdown];
        });
    }
}
