<?php
declare(strict_types=1);

namespace Martello\Services;

use Martello\Core\JsonDataStore;
use Martello\Patterns\Observer\AuctionSubject;
use RuntimeException;

/**
 * FR-01..FR-37 Kapsamındaki Tüm Yan İş Akışlarını Yöneten Uygulama Servisi:
 * - Bakiye Yükleme (Kullanıcı Hikayesi 7)
 * - Satıcı Ürün & İlan Ekleme (FR-07, FR-31)
 * - Ekspertiz Raporu Oluşturma ve Üst Birime Eskalasyon (FR-18, Senaryo 10)
 * - Admin İlan Onaylama/Reddetme (FR-09), Kullanıcı Askıya Alma/Ban (FR-06), Komisyon Güncelleme (FR-22)
 * - Canlı Destek Sohbet Mesajı Gönderme ve Kargo Sorgulama (FR-27, Senaryo 4 & 9)
 * - Alıcı İhtilaf/İtiraz Talebi Oluşturma (FR-20, Senaryo 13)
 */
class PlatformWorkflowService
{
    public function __construct(
        private JsonDataStore $store,
        private AuctionSubject $auctionSubject
    ) {}

    public function topUpWallet(int $userId, float $amount): array
    {
        return $this->store->executeTransaction("wallet_{$userId}", function (array &$dbData) use ($userId, $amount): array {
            foreach ($dbData['wallets'] as &$wallet) {
                if ((int) $wallet['kullaniciId'] === $userId) {
                    $wallet['bakiye']        = round((float) $wallet['bakiye'] + $amount, 2);
                    $wallet['sonGuncelleme'] = date('c');
                    return $wallet;
                }
            }
            throw new RuntimeException("Cüzdan bulunamadı.");
        });
    }

    public function createProductAndListing(int $sellerId, string $title, int $categoryId, string $condition, float $startPrice, float $reservePrice): array
    {
        return $this->store->executeTransaction("catalog_write", function (array &$dbData) use ($sellerId, $title, $categoryId, $condition, $startPrice, $reservePrice): array {
            if (trim($title) === '' || $startPrice <= 0) {
                throw new RuntimeException('FR-31: Ürün adı, kategori ve başlangıç fiyatı zorunludur.');
            }
            $newProdId = count($dbData['products']) + 501;
            $product   = [
                'id'                => $newProdId,
                'saticiId'          => $sellerId,
                'kategoriId'        => $categoryId,
                'baslik'            => $title,
                'aciklama'          => "{$title} — Satıcı tarafından ekspertiz incelemesine sunulan koleksiyon eseri.",
                'fizikselKondisyon' => $condition,
                'orijinallikDurumu' => 'Ekspertiz Bekliyor',
                'gorseller'         => ['yeni_urun_vitrin.jpg'],
            ];
            $dbData['products'][] = $product;

            $reqId = count($dbData['appraisalRequests']) + 201;
            $dbData['appraisalRequests'][] = [
                'id'             => $reqId,
                'talepNo'        => 'EXP-REQ-' . (440 + count($dbData['appraisalRequests'])),
                'lotKodu'        => 'AUC-' . (1045 + count($dbData['appraisalRequests'])),
                'urunId'         => $newProdId,
                'atananEksperId' => 4,
                'durum'          => 'BEKLEYEN',
                'eskalasyon'     => false,
                'not'            => 'Yeni satıcı ilanı — Fiziksel kondisyon ve özgünlük incelemesi bekliyor.',
            ];

            $listing = [
                'id'               => count($dbData['listings']) + 601,
                'ilanKodu'         => 'ILN-2026-' . (100 + count($dbData['listings'])),
                'urunId'           => $newProdId,
                'saticiId'         => $sellerId,
                'ekspertizRaporId' => null,
                'baslangicFiyati'  => $startPrice,
                'rezervFiyat'      => $reservePrice,
                'durum'            => 'TASLAK_EKSPERTIZ_BEKLIYOR',
            ];
            $dbData['listings'][] = $listing;

            return ['product' => $product, 'listing' => $listing];
        });
    }

    public function submitAppraisalReport(int $requestId, int $appraiserId, float $suggestedValue, string $authenticityNote, bool $escalateToAdmin = false): array
    {
        return $this->store->executeTransaction("appraisal_{$requestId}", function (array &$dbData) use ($requestId, $appraiserId, $suggestedValue, $authenticityNote, $escalateToAdmin): array {
            foreach ($dbData['appraisalRequests'] as &$req) {
                if ((int) $req['id'] === $requestId) {
                    if ($escalateToAdmin) {
                        $req['durum']      = 'ESKALE_EDILDI_ADMIN_INCELEMESINDE';
                        $req['eskalasyon'] = true;
                        $req['not']        = 'Senaryo 10: Uzman tarafından üst birime (Admin) eskale edildi: ' . $authenticityNote;
                        return ['status' => 'ESCALATED', 'request' => $req];
                    }

                    $req['durum'] = 'TAMAMLANDI';
                    $report       = [
                        'id'                   => count($dbData['appraisalReports']) + 301,
                        'raporNo'              => 'REP-2026-' . (115 + count($dbData['appraisalReports'])),
                        'talepId'              => $requestId,
                        'urunId'               => (int) $req['urunId'],
                        'eksperId'             => $appraiserId,
                        'onerilenPiyasaDegeri' => $suggestedValue,
                        'orijinallikNotu'      => $authenticityNote,
                        'maddeler'             => [$authenticityNote],
                        'denetimDurumu'        => 'ONAYLANDI',
                        'raporTarihi'          => date('c'),
                    ];
                    $dbData['appraisalReports'][] = $report;
                    return ['status' => 'REPORT_CREATED', 'report' => $report];
                }
            }
            throw new RuntimeException('Ekspertiz talebi bulunamadı.');
        });
    }

    public function toggleUserBanStatus(int $targetUserId, string $newStatus): array
    {
        return $this->store->executeTransaction("user_{$targetUserId}", function (array &$dbData) use ($targetUserId, $newStatus): array {
            foreach ($dbData['users'] as &$u) {
                if ((int) $u['id'] === $targetUserId) {
                    $u['durum'] = $newStatus;
                    return $u;
                }
            }
            throw new RuntimeException('Kullanıcı bulunamadı.');
        });
    }

    public function createDispute(int $userId, int $lotId, string $issueType, string $description): array
    {
        return $this->store->executeTransaction("dispute_write", function (array &$dbData) use ($userId, $lotId, $issueType, $description): array {
            $dispute = [
                'id'                   => count($dbData['disputes']) + 8801,
                'talepNo'              => 'DISP-2026-' . (10 + count($dbData['disputes'])),
                'lotId'                => $lotId,
                'lotKodu'              => 'AUC-' . $lotId,
                'siparisId'            => 5001,
                'olusturanKullaniciId' => $userId,
                'konuTipi'             => $issueType,
                'aciklama'             => $description,
                'durum'                => 'INCELENIYOR',
                'olusturmaTarihi'      => date('c'),
            ];
            $dbData['disputes'][] = $dispute;
            return $dispute;
        });
    }

    public function addSupportChatMessage(int $senderId, string $senderName, string $messageText): array
    {
        return $this->store->executeTransaction("chat_write", function (array &$dbData) use ($senderId, $senderName, $messageText): array {
            $msg = [
                'gonderenId' => $senderId,
                'gonderenAd' => $senderName,
                'icerik'     => $messageText,
                'zaman'      => date('Y-m-d H:i:s'),
            ];
            $dbData['liveChatSessions'][0]['mesajlar'][] = $msg;
            return $msg;
        });
    }
}
