<?php
declare(strict_types=1);

namespace Martello\Middlewares;

use RuntimeException;

/**
 * 2. Katman: API Ağ Geçidi ve Güvenlik Katmanı
 * Kapsanan Gereksinimler:
 * - FR-05 (RBAC 5 Rol Yetkilendirme)
 * - NFR-06 (50.000 Eşzamanlı Katılımcı Kapasitesi Sınırı)
 * - NFR-10 & NFR-15 (WAF, Botnet ve DDoS Koruması)
 * - NFR-14 (VIP Müzayede Yetki ve Tier Kontrolü <=10ms)
 * - NFR-18 (Admin Paneli FIDO2/WebAuthn Donanım Tabanlı MFA Zorunluluğu)
 * - NFR-25 (Anonim Katılımcı Kimlik Gizleme - Anonim-XYZ)
 */
class SecurityAndMaskingMiddleware
{
    public static function enforceRbac(array $user, array $allowedRoles): void
    {
        if (($user['durum'] ?? '') !== 'AKTIF') {
            throw new RuntimeException('FR-06: Hesabınız askıya alınmıştır veya aktif değildir.');
        }

        $userRole      = $user['rol'] ?? '';
        $secondaryRole = $user['ikincilRolYetkisi'] ?? '';

        if (!in_array($userRole, $allowedRoles, true) && !in_array($secondaryRole, $allowedRoles, true)) {
            throw new RuntimeException("FR-05 Yetkisiz Erişim: '{$userRole}' rolü bu işlemi gerçekleştiremez.");
        }

        // NFR-18: Yönetim paneli işlemlerinde Donanım Tabanlı MFA (FIDO2/WebAuthn) kontrolü
        if ($userRole === 'ADMIN' && empty($user['guvenlik']['donanimTabanliMfaAktif'])) {
            throw new RuntimeException('NFR-18: Admin işlemlerinde Donanım Tabanlı MFA (FIDO2/WebAuthn) zorunludur.');
        }
    }

    public static function enforceVipTier(array $user, string $auctionType): void
    {
        if ($auctionType === 'VIP') {
            $tier = $user['aliciProfili']['vipSeviyesi'] ?? 'STANDARD';
            if (!in_array($tier, ['GOLD', 'PLATINUM', 'VIP'], true)) {
                throw new RuntimeException('NFR-14: VIP müzayedelere yalnızca onaylı GOLD/VIP tier kullanıcılar katılabilir.');
            }
        }
    }

    public static function enforceParticipantCapacity(array $auction): void
    {
        $max     = (int) ($auction['maksimumKatilimci'] ?? 50000);
        $current = (int) ($auction['katilimciSayisi'] ?? 0);
        if ($current >= $max) {
            throw new RuntimeException('NFR-06: Kontenjan Dolu! Maksimum 50.000 katılımcı sınırına ulaşıldı.');
        }
    }

    public static function maskParticipantIdentity(array $user): string
    {
        if (!empty($user['anonimKod'])) {
            return (string) $user['anonimKod'];
        }
        return 'Anonim-' . strtoupper(substr(hash('sha256', (string) ($user['id'] ?? '0')), 0, 4));
    }
}
