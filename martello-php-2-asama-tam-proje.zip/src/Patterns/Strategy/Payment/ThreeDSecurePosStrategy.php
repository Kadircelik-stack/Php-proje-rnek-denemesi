<?php
declare(strict_types=1);

namespace Martello\Patterns\Strategy\Payment;

/**
 * 3D Secure Sanal POS Ödeme Stratejisi (<=3 sn onay - FR-28, NFR-09)
 */
class ThreeDSecurePosStrategy implements IPaymentStrategy
{
    public function processAndBlockFunds(array &$dbData, int $buyerId, int $lotId, int $bidId, float $amount, string $currency): string
    {
        return '3DS-POS-AUTH-' . $bidId . '-' . random_int(1000, 9999);
    }
}
