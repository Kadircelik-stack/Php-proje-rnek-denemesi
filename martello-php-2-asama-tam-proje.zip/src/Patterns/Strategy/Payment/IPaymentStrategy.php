<?php
declare(strict_types=1);

namespace Martello\Patterns\Strategy\Payment;

interface IPaymentStrategy
{
    public function processAndBlockFunds(array &$dbData, int $buyerId, int $lotId, int $bidId, float $amount, string $currency): string;
}
