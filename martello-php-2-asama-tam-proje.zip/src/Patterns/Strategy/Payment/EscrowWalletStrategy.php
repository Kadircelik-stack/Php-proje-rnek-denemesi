<?php
declare(strict_types=1);

namespace Martello\Patterns\Strategy\Payment;

use RuntimeException;

/**
 * Emanet (Escrow) Cüzdan Bloke ve Aktarım Stratejisi (FR-23, FR-24, R-02)
 */
class EscrowWalletStrategy implements IPaymentStrategy
{
    public function processAndBlockFunds(array &$dbData, int $buyerId, int $lotId, int $bidId, float $amount, string $currency): string
    {
        foreach ($dbData['wallets'] as &$wallet) {
            if ((int) $wallet['kullaniciId'] === $buyerId) {
                if ((float) $wallet['bakiye'] < $amount) {
                    throw new RuntimeException(
                        sprintf('FR-23 Yetersiz Bakiye! Kullanılabilir: %.2f %s, Gerekli Teminat: %.2f %s', $wallet['bakiye'], $currency, $amount, $currency)
                    );
                }

                $wallet['bakiye']      = round((float) $wallet['bakiye'] - $amount, 2);
                $wallet['blokeBakiye'] = round((float) $wallet['blokeBakiye'] + $amount, 2);
                $blokeId               = 'BLK-' . date('Y') . '-' . $bidId;

                $wallet['aktifBlokeler'][] = [
                    'blokeId'         => $blokeId,
                    'lotId'           => $lotId,
                    'peyId'           => $bidId,
                    'tutar'           => $amount,
                    'paraBirimi'      => $currency,
                    'durum'           => 'EMANET_BLOKE_AKTIF',
                    'olusturmaZamani' => date('c'),
                ];
                $wallet['sonGuncelleme'] = date('c');

                return $blokeId;
            }
        }
        throw new RuntimeException("Kullanıcı cüzdanı bulunamadı: #{$buyerId}");
    }
}
