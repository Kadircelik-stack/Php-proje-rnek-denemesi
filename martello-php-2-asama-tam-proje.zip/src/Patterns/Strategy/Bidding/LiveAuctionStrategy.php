<?php
declare(strict_types=1);

namespace Martello\Patterns\Strategy\Bidding;

use InvalidArgumentException;

/**
 * Canlı Müzayede Pey Adımı ve Anti-Sniping (Son 30sn -> +30sn / +10sn) Stratejisi
 * Kapsanan Gereksinimler: FR-12, FR-13, FR-32, FR-33, NFR-23
 */
class LiveAuctionStrategy implements IBiddingRuleStrategy
{
    public function validateAndApplyAntiSnipe(
        array &$lot,
        float $bidAmount,
        int $currentTimestamp,
        array $antiSnipeConfig
    ): array {
        if (($lot['durum'] ?? '') !== 'ACIK_ARTIRMADA') {
            throw new InvalidArgumentException('Bu lot şu anda açık artırmada değil.');
        }

        $minRequiredBid = (float) $lot['mevcutEnYuksekTeklif'] + (float) $lot['minimumArtisTutari'];
        if ($bidAmount < $minRequiredBid) {
            throw new InvalidArgumentException(
                sprintf('FR-32 Geçersiz Pey! Minimum geçerli teklif tutarı: %.2f %s', $minRequiredBid, $lot['paraBirimi'])
            );
        }

        // FR-33 & NFR-23: Son 30 saniyede teklif gelirse ilk 2 uzamada +30sn, 3. ve sonrasında +10sn uzat
        $endTimeTs        = strtotime((string) $lot['antiSnipingSayaci']['sonBitisZamani']);
        $remainingSeconds = $endTimeTs - $currentTimestamp;
        $extendedSeconds  = 0;

        $threshold = (int) ($antiSnipeConfig['thresholdSeconds'] ?? 30);
        if ($remainingSeconds > 0 && $remainingSeconds <= $threshold) {
            $extCount        = (int) ($lot['antiSnipingSayaci']['uzatmaSayisi'] ?? 0);
            $extendedSeconds = $extCount < 2
                ? (int) ($antiSnipeConfig['firstTwoExtensionsSeconds'] ?? 30)
                : (int) ($antiSnipeConfig['subsequentExtensionsSeconds'] ?? 10);

            $newEndTimestamp = $endTimeTs + $extendedSeconds;
            $lot['antiSnipingSayaci']['uzatmaSayisi']   = $extCount + 1;
            $lot['antiSnipingSayaci']['sonBitisZamani'] = date('c', $newEndTimestamp);
        }

        return [
            'isValid'         => true,
            'extendedSeconds' => $extendedSeconds,
            'newEndTimeIso'   => $lot['antiSnipingSayaci']['sonBitisZamani'],
        ];
    }
}
