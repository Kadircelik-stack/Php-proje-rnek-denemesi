<?php
declare(strict_types=1);

namespace Martello\Patterns\Strategy\Bidding;

/**
 * VIP Müzayede Stratejisi (NFR-14, NFR-15, NFR-22)
 */
class VipAuctionStrategy extends LiveAuctionStrategy
{
    // VIP müzayedelerde özel artırım ve anti-sniping kurallarını izole olarak uygular.
}
