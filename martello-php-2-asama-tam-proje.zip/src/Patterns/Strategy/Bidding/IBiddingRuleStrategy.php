<?php
declare(strict_types=1);

namespace Martello\Patterns\Strategy\Bidding;

interface IBiddingRuleStrategy
{
    public function validateAndApplyAntiSnipe(
        array &$lot,
        float $bidAmount,
        int $currentTimestamp,
        array $antiSnipeConfig
    ): array;
}
