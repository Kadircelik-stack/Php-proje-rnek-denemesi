<?php
declare(strict_types=1);

namespace Martello\Patterns\Strategy\Currency;

class TryCurrencyStrategy implements ICurrencyStrategy
{
    public function convertFromTry(float $amountInTry, array $rates): float
    {
        return round($amountInTry, 2);
    }
    public function getSymbol(): string { return '₺'; }
    public function getCode(): string { return 'TRY'; }
}
