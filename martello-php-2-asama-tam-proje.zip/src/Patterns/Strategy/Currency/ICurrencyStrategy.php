<?php
declare(strict_types=1);

namespace Martello\Patterns\Strategy\Currency;

interface ICurrencyStrategy
{
    public function convertFromTry(float $amountInTry, array $rates): float;
    public function getSymbol(): string;
    public function getCode(): string;
}
