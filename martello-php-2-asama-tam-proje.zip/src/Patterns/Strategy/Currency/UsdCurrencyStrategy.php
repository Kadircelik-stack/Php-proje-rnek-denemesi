<?php
declare(strict_types=1);

namespace Martello\Patterns\Strategy\Currency;

class UsdCurrencyStrategy implements ICurrencyStrategy
{
    public function convertFromTry(float $amountInTry, array $rates): float
    {
        $rate = (float) ($rates['USD'] ?? 34.50);
        return round($amountInTry / $rate, 2);
    }
    public function getSymbol(): string { return '$'; }
    public function getCode(): string { return 'USD'; }
}
