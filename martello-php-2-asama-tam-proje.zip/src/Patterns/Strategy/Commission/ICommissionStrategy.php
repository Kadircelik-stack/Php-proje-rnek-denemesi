<?php
declare(strict_types=1);

namespace Martello\Patterns\Strategy\Commission;

interface ICommissionStrategy
{
    public function calculateBreakdown(float $closingPrice, array $category): array;
}
