<?php
declare(strict_types=1);

namespace Martello\Patterns\Strategy\Commission;

class VehicleCommission implements ICommissionStrategy
{
    public function calculateBreakdown(float $closingPrice, array $category): array
    {
        $rate              = (float) ($category['komisyonOraniYuzde'] ?? 5.0) / 100.0;
        $commissionAmount  = round($closingPrice * $rate, 2);
        $appraisalFee      = (float) ($category['sabitEkspertizUcreti'] ?? 3000.0);
        return [
            'kapanisBedeli'          => $closingPrice,
            'komisyonOraniYuzde'     => (float) ($category['komisyonOraniYuzde'] ?? 5.0),
            'komisyonTutari'         => $commissionAmount,
            'ekspertizHizmetBedeli'  => $appraisalFee,
            'toplamTutar'            => round($closingPrice + $commissionAmount, 2),
            'saticiNetHakedisTutari' => round($closingPrice - $appraisalFee, 2),
        ];
    }
}
