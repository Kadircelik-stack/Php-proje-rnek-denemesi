<?php
declare(strict_types=1);

namespace Martello\Patterns\Strategy\Commission;

/**
 * Sanat ve Antika Kategorisi Komisyon ve Ekspertiz Ücreti Stratejisi (FR-08, FR-22)
 */
class ArtAntiqueCommission implements ICommissionStrategy
{
    public function calculateBreakdown(float $closingPrice, array $category): array
    {
        $rate              = (float) ($category['komisyonOraniYuzde'] ?? 8.0) / 100.0;
        $commissionAmount  = round($closingPrice * $rate, 2);
        $appraisalFee      = (float) ($category['sabitEkspertizUcreti'] ?? 1500.0);
        $buyerTotalPayable = round($closingPrice + $commissionAmount, 2);
        $sellerNetPayout   = round($closingPrice - $appraisalFee, 2);

        return [
            'kapanisBedeli'          => $closingPrice,
            'komisyonOraniYuzde'     => (float) ($category['komisyonOraniYuzde'] ?? 8.0),
            'komisyonTutari'         => $commissionAmount,
            'ekspertizHizmetBedeli'  => $appraisalFee,
            'toplamTutar'            => $buyerTotalPayable,
            'saticiNetHakedisTutari' => $sellerNetPayout,
        ];
    }
}
