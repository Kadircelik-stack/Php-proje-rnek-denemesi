<?php
declare(strict_types=1);

namespace Martello\Patterns\Observer;

class AuctionSubject
{
    /** @var IAuctionObserver[] */
    private array $observers = [];

    public function subscribe(IAuctionObserver $observer): void
    {
        $this->observers[] = $observer;
    }

    public function notifyObservers(string $eventType, array &$context): void
    {
        foreach ($this->observers as $observer) {
            $observer->onAuctionEvent($eventType, $context);
        }
    }
}
