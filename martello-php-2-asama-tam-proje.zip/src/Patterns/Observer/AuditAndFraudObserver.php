<?php
declare(strict_types=1);

namespace Martello\Patterns\Observer;

class AuditAndFraudObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        $logs     = $context['dbData']['auditLogs'] ?? [];
        $lastLog  = !empty($logs) ? end($logs) : null;
        $prevHash = $lastLog['currentHash'] ?? str_repeat('0', 64);

        $buyer    = $context['buyer'] ?? ['id' => 0, 'rol' => 'SISTEM'];
        $lot      = $context['lot'] ?? ['id' => 0];
        $sellerId = (int) ($context['sellerId'] ?? -1);
        $isSelf   = ((int) $buyer['id'] === $sellerId);

        $logEntry = [
            'logId'                    => sprintf('WORM-AUDIT-%04d', count($logs) + 1),
            'zamanDamgasi'             => date('c'),
            'kullaniciId'              => (int) $buyer['id'],
            'kullaniciRol'             => $buyer['rol'],
            'ipAdresi'                 => $context['ipAddress'] ?? '127.0.0.1',
            'cihazParmakIzi'           => 'FP-WEB-CLIENT',
            'islemTipi'                => $eventType,
            'hedefVarlik'              => 'Lot:' . $lot['id'],
            'shillBiddingAnomaliSkoru' => $isSelf ? 0.99 : 0.01,
            'shillBiddingDurumu'       => $isSelf ? 'SHILL_BIDDING_SUPHESI' : 'TEMIZ',
            'prevHash'                 => $prevHash,
        ];
        $logEntry['currentHash'] = hash('sha256', json_encode($logEntry, JSON_UNESCAPED_UNICODE));
        $context['dbData']['auditLogs'][] = $logEntry;
    }
}
