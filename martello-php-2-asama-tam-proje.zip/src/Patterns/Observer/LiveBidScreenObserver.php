<?php
declare(strict_types=1);

namespace Martello\Patterns\Observer;

class LiveBidScreenObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        if ($eventType !== 'BID_PLACED') {
            return;
        }
        $lot   = $context['lot'];
        $buyer = $context['buyer'];

        $context['realtimeBroadcasts'][] = [
            'channel'             => 'ws://martello.local/auctions/' . $lot['muzayedeId'] . '/lots/' . $lot['id'],
            'event'               => 'LIVE_PRICE_UPDATE',
            'lotKodu'             => $lot['lotKodu'],
            'guncelTeklif'        => $lot['mevcutEnYuksekTeklif'],
            'paraBirimi'          => $lot['paraBirimi'],
            'liderAnonimKod'      => $buyer['anonimKod'],
            'maxDeliveryTargetMs' => 300,
            'timestamp'           => microtime(true),
        ];
    }
}
