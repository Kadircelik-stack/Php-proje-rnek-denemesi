<?php
declare(strict_types=1);

namespace Martello\Patterns\Observer;

class WatchlistObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        if ($eventType !== 'BID_PLACED') {
            return;
        }
        $lotId = (int) $context['lot']['id'];
        foreach ($context['dbData']['watchlists'] as &$item) {
            if ((int) $item['lotId'] === $lotId) {
                $item['sonGorulenFiyat'] = $context['lot']['mevcutEnYuksekTeklif'];
            }
        }
    }
}
