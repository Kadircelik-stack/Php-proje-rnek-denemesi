<?php
declare(strict_types=1);

namespace Martello\Patterns\Observer;

class OrderAndReminderObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        if ($eventType !== 'AUCTION_CLOSED') {
            return;
        }
        $lot        = $context['lot'];
        $winningBid = $context['winningBid'];
        $breakdown  = $context['commissionBreakdown'];

        $context['dbData']['orders'][] = [
            'id'               => count($context['dbData']['orders']) + 5001,
            'siparisNo'        => 'ORD-' . date('Y') . '-' . $lot['id'],
            'lotId'            => (int) $lot['id'],
            'lotKodu'          => $lot['lotKodu'],
            'urunBaslik'       => $lot['baslik'],
            'kategoriAdi'      => $lot['kategoriAdi'] ?? 'Sanat',
            'muzayedeId'       => (int) $lot['muzayedeId'],
            'urunId'           => (int) $lot['urunId'],
            'aliciId'          => (int) $winningBid['aliciId'],
            'saticiId'         => (int) $context['sellerId'],
            'kazananPeyId'     => (int) $winningBid['id'],
            'sonTarih'         => date('d-m-Y'),
            'kapanisFiyati'    => $breakdown['kapanisBedeli'],
            'komisyonTutari'   => $breakdown['komisyonTutari'],
            'genelToplamTutar' => $breakdown['toplamTutar'],
            'paraBirimi'       => $lot['paraBirimi'],
            'siparisDurumu'    => 'Ödeme Bekliyor',
            'kargoTakipNo'     => 'KRG-' . random_int(10000000, 99999999),
        ];
    }
}
