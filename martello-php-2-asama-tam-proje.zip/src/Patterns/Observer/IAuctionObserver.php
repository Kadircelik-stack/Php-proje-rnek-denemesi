<?php
declare(strict_types=1);

namespace Martello\Patterns\Observer;

interface IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void;
}
