<?php
declare(strict_types=1);

namespace Martello\Patterns\Observer;

class EscrowReleaseObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        if ($eventType !== 'BID_PLACED' || empty($context['previousHighestBid'])) {
            return;
        }

        $prevBid     = $context['previousHighestBid'];
        $prevBuyerId = (int) $prevBid['aliciId'];
        $refundAmt   = (float) $prevBid['teklifTutari'];

        foreach ($context['dbData']['wallets'] as &$wallet) {
            if ((int) $wallet['kullaniciId'] === $prevBuyerId) {
                $wallet['blokeBakiye']   = max(0.0, round((float) $wallet['blokeBakiye'] - $refundAmt, 2));
                $wallet['bakiye']        = round((float) $wallet['bakiye'] + $refundAmt, 2);
                $wallet['sonGuncelleme'] = date('c');
                break;
            }
        }

        foreach ($context['dbData']['bids'] as &$bidRecord) {
            if ((int) $bidRecord['id'] === (int) $prevBid['id']) {
                $bidRecord['durum'] = 'GECILDI_BLOKESI_COZULDU';
                break;
            }
        }
    }
}
