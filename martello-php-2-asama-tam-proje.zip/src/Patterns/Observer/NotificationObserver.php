<?php
declare(strict_types=1);

namespace Martello\Patterns\Observer;

class NotificationObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        if ($eventType !== 'BID_PLACED' || empty($context['previousHighestBid'])) {
            return;
        }
        $prevBid = $context['previousHighestBid'];
        $lot     = $context['lot'];

        $context['dbData']['notifications'][] = [
            'id'             => count($context['dbData']['notifications']) + 6001,
            'kullaniciId'    => (int) $prevBid['aliciId'],
            'ilgiliLotId'    => (int) $lot['id'],
            'olayTipi'       => 'TEKLIF_GECILDI_OUTBID',
            'kanallar'       => ['PUSH', 'SMS', 'EMAIL'],
            'baslik'         => "Teklifiniz Geçildi! ({$lot['lotKodu']})",
            'icerik'         => sprintf(
                'Yeni en yüksek teklif: %.2f %s. Önceki %.2f %s bloke tutarınız cüzdanınıza iade edilmiştir.',
                $lot['mevcutEnYuksekTeklif'],
                $lot['paraBirimi'],
                $prevBid['teklifTutari'],
                $lot['paraBirimi']
            ),
            'okunduMu'       => false,
            'gonderimZamani' => date('c'),
        ];
    }
}
