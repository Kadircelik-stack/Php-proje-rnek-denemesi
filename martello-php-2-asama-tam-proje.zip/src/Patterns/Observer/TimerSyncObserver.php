<?php
declare(strict_types=1);

namespace Martello\Patterns\Observer;

class TimerSyncObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        if ($eventType === 'BID_PLACED' && ($context['extendedSeconds'] ?? 0) > 0) {
            $context['realtimeBroadcasts'][] = [
                'event'           => 'ANTI_SNIPING_TIMER_EXTENDED',
                'lotId'           => $context['lot']['id'],
                'eklenenSaniye'   => $context['extendedSeconds'],
                'yeniBitisZamani' => $context['lot']['antiSnipingSayaci']['sonBitisZamani'],
                'ntpServerTime'   => date('c'),
            ];
        }
    }
}
