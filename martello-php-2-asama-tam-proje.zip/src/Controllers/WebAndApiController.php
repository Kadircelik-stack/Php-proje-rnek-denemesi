<?php
declare(strict_types=1);

namespace Martello\Controllers;

use Martello\Core\JsonDataStore;
use Martello\Patterns\Strategy\Currency\EurCurrencyStrategy;
use Martello\Patterns\Strategy\Currency\ICurrencyStrategy;
use Martello\Patterns\Strategy\Currency\TryCurrencyStrategy;
use Martello\Patterns\Strategy\Currency\UsdCurrencyStrategy;
use Martello\Services\AuctionEngineService;
use Martello\Services\PlatformWorkflowService;
use Throwable;

/**
 * 2. Katman: Denetleyici (Controller) Katmanı
 * Hem Web Form / Görünüm (views/) isteklerini hem de JSON API uç noktalarını yönetir.
 */
class WebAndApiController
{
    public function __construct(
        private JsonDataStore $store,
        private AuctionEngineService $auctionService,
        private PlatformWorkflowService $workflowService
    ) {}

    public function resolveCurrencyStrategy(string $code): ICurrencyStrategy
    {
        return match (strtoupper($code)) {
            'USD'   => new UsdCurrencyStrategy(),
            'EUR'   => new EurCurrencyStrategy(),
            default => new TryCurrencyStrategy(),
        };
    }

    public function handlePostAction(array $post): array
    {
        $action = $post['action'] ?? '';
        try {
            switch ($action) {
                case 'place_bid':
                    $res = $this->auctionService->placeBid(
                        (int) ($post['lot_id'] ?? 1002),
                        (int) ($post['buyer_id'] ?? 6),
                        (float) ($post['bid_amount'] ?? 0),
                        $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
                    );
                    $msg = "FR-13 & FR-34: Teklifiniz başarıyla kaydedildi ve bloke edildi! Güncel Lider: {$res['updatedLot']['liderAnonimKod']} ({$res['updatedLot']['mevcutEnYuksekTeklif']} TRY).";
                    if (!empty($res['autoProxyResponse'])) {
                        $msg .= " [NFR-24 Otomatik Teklif / Proxy Bidding devreye girdi: {$res['autoProxyResponse']['aliciAnonimKod']} adına {$res['updatedLot']['mevcutEnYuksekTeklif']} TRY karşı teklif basıldı!]";
                    }
                    return ['type' => 'success', 'message' => $msg, 'data' => $res];

                case 'set_proxy_bid':
                    $res = $this->auctionService->setProxyBid(
                        (int) ($post['lot_id'] ?? 1001),
                        (int) ($post['buyer_id'] ?? 3),
                        (float) ($post['max_budget'] ?? 80000)
                    );
                    return ['type' => 'success', 'message' => "NFR-24: Otomatik Teklif (Proxy Bidding) tavan bütçeniz {$res['maksimumButceTutari']} TRY olarak tanımlandı."];

                case 'topup_wallet':
                    $wallet = $this->workflowService->topUpWallet(
                        (int) ($post['user_id'] ?? 3),
                        (float) ($post['amount'] ?? 25000)
                    );
                    return ['type' => 'success', 'message' => "Kullanıcı Hikayesi 7: Cüzdanınıza bakiye yüklendi. Güncel Kullanılabilir Bakiye: {$wallet['bakiye']} TRY."];

                case 'create_listing':
                    $res = $this->workflowService->createProductAndListing(
                        (int) ($post['seller_id'] ?? 2),
                        (string) ($post['title'] ?? ''),
                        (int) ($post['category_id'] ?? 10),
                        (string) ($post['condition'] ?? 'Çok İyi'),
                        (float) ($post['start_price'] ?? 20000),
                        (float) ($post['reserve_price'] ?? 30000)
                    );
                    return ['type' => 'success', 'message' => "FR-07 & FR-31: '{$res['product']['baslik']}' ürünü eklendi ve '{$res['listing']['ilanKodu']}' koduyla ekspertiz incelemesine gönderildi."];

                case 'submit_appraisal':
                    $escalate = !empty($post['escalate']);
                    $res      = $this->workflowService->submitAppraisalReport(
                        (int) ($post['request_id'] ?? 202),
                        4,
                        (float) ($post['suggested_value'] ?? 55000),
                        (string) ($post['note'] ?? 'Orijinallik ve mekanizma kondisyonu onaylandı.'),
                        $escalate
                    );
                    if ($res['status'] === 'ESCALATED') {
                        return ['type' => 'warning', 'message' => 'Senaryo 10: İhtilaflı/karmaşık ekspertiz talebi üst birime (Admin) eskale edildi.'];
                    }
                    return ['type' => 'success', 'message' => "FR-18: Ekspertiz raporu ({$res['report']['raporNo']}) e-imzalı olarak oluşturuldu ve Admin onayına sunuldu."];

                case 'toggle_ban':
                    $user = $this->workflowService->toggleUserBanStatus(
                        (int) ($post['target_user_id'] ?? 6),
                        (string) ($post['new_status'] ?? 'ASKIYA_ALINDI')
                    );
                    return ['type' => 'warning', 'message' => "FR-06: {$user['ad']} {$user['soyad']} hesap durumu '{$user['durum']}' olarak güncellendi."];

                case 'close_lot':
                    $res = $this->auctionService->closeLotAndCreateOrder((int) ($post['lot_id'] ?? 1001));
                    return ['type' => 'success', 'message' => "FR-10 & FR-29: Müzayede sonlandırıldı, otomatik sipariş ve %8 kategori komisyonu oluşturuldu."];

                case 'create_dispute':
                    $disp = $this->workflowService->createDispute(
                        (int) ($post['user_id'] ?? 3),
                        (int) ($post['lot_id'] ?? 1001),
                        (string) ($post['issue_type'] ?? 'KONDİSYON_UYUŞMAZLIĞI'),
                        (string) ($post['description'] ?? 'Kargo teslimatı sonrası kondisyon inceleme talebi.')
                    );
                    return ['type' => 'warning', 'message' => "FR-20: İhtilaf/İtiraz talebiniz ({$disp['talepNo']}) oluşturuldu ve emanet ödeme bloke altına alındı."];

                case 'send_chat':
                    $this->workflowService->addSupportChatMessage(
                        (int) ($post['sender_id'] ?? 5),
                        (string) ($post['sender_name'] ?? 'Elif Ç. (Canlı Destek)'),
                        (string) ($post['message'] ?? '')
                    );
                    return ['type' => 'success', 'message' => 'FR-27: Canlı sohbet mesajı iletildi ve WORM sohbet loguna kaydedildi.'];

                default:
                    return ['type' => 'info', 'message' => 'İşlem seçilmedi.'];
            }
        } catch (Throwable $e) {
            return ['type' => 'error', 'message' => $e->getMessage()];
        }
    }
}
