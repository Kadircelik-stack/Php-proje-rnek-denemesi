<?php
declare(strict_types=1);

namespace Martello\Core;

use RuntimeException;
use Throwable;

/**
 * 4. Katman: Veri Erişim ve Kalıcılık Çekirdeği (JsonDataStore)
 * Kapsanan Gereksinimler:
 * - NFR-04 (Yarış Durumu Yönetimi ve Eşzamanlılık - Pessimistic Lock LOCK_EX)
 * - NFR-05 (Veritabanı Tutarlılığı - Tam ACID Transaction & Rollback)
 * - NFR-12 (KVKK / GDPR AES-256 Sütun Şifreleme)
 * - NFR-19 (Argon2id Parola Güvenliği ve Tuzlama)
 */
class JsonDataStore
{
    private string $dataFilePath;
    private string $lockDirPath;
    private array $data = [];

    public function __construct(string $dataFilePath, string $lockDirPath)
    {
        $this->dataFilePath = $dataFilePath;
        $this->lockDirPath  = rtrim($lockDirPath, '/\\');

        if (!is_dir($this->lockDirPath)) {
            mkdir($this->lockDirPath, 0775, true);
        }
        $this->reload();
    }

    public function reload(): void
    {
        if (!file_exists($this->dataFilePath)) {
            throw new RuntimeException("JSON veri deposu bulunamadı: {$this->dataFilePath}");
        }
        $rawContent = file_get_contents($this->dataFilePath);
        $decoded    = json_decode((string) $rawContent, true, 512, JSON_THROW_ON_ERROR);
        $this->data = is_array($decoded) ? $decoded : [];
    }

    public function getAllData(): array
    {
        return $this->data;
    }

    public function getCollection(string $collectionName): array
    {
        return $this->data[$collectionName] ?? [];
    }

    public function getSystemParameters(): array
    {
        return $this->data['systemParameters'] ?? [];
    }

    /**
     * NFR-04 & NFR-05: Karamsar Kilit (SELECT ... FOR UPDATE) ve Atomik Transaction
     */
    public function executeTransaction(string $resourceLockKey, callable $callback): mixed
    {
        $lockFile = $this->lockDirPath . DIRECTORY_SEPARATOR . md5($resourceLockKey) . '.lock';
        $handle   = fopen($lockFile, 'c+');

        if ($handle === false) {
            throw new RuntimeException("Kilit dosyası açılamadı: {$lockFile}");
        }

        if (!flock($handle, LOCK_EX)) {
            fclose($handle);
            throw new RuntimeException("Kaynak kilidi alınamadı (Race Condition Koruması): {$resourceLockKey}");
        }

        $this->reload();
        $snapshot = $this->data;

        try {
            $result = $callback($this->data);
            $this->data['metadata']['lastSyncTimestamp'] = date('c');

            $tempFile = $this->dataFilePath . '.tmp.' . uniqid('', true);
            $jsonOut  = json_encode($this->data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            file_put_contents($tempFile, $jsonOut, LOCK_EX);
            rename($tempFile, $this->dataFilePath);

            return $result;
        } catch (Throwable $e) {
            $this->data = $snapshot;
            throw $e;
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }

    public static function hashPassword(string $plainPassword): string
    {
        $algo = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
        return password_hash($plainPassword, $algo);
    }

    public static function encryptField(string $plainText, string $secretKey = 'MARTELLO_KVKK_KEY_2026'): string
    {
        $iv         = random_bytes(12);
        $tag        = '';
        $cipherText = openssl_encrypt($plainText, 'aes-256-gcm', hash('sha256', $secretKey, true), OPENSSL_RAW_DATA, $iv, $tag);
        return 'AES256::' . base64_encode($iv . $tag . (string) $cipherText);
    }
}
