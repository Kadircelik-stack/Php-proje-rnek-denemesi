/**
 * MARTELLO İstemci Tarafı Canlı Sayaç, Kur Dönüşümü ve Bellek Yönetimi (FR-34, FR-35, NFR-02, NFR-20)
 */
(function () {
  const activeIntervals = [];

  function initCountdowns() {
    const timers = document.querySelectorAll('[data-countdown-seconds]');
    timers.forEach((el) => {
      let remaining = parseInt(el.getAttribute('data-countdown-seconds'), 10) || 19380;
      const intervalId = setInterval(() => {
        if (remaining > 0) {
          remaining--;
          const hrs = Math.floor(remaining / 3600);
          const mins = Math.floor((remaining % 3600) / 60);
          const secs = remaining % 60;
          el.textContent =
            String(hrs).padStart(2, '0') + ' saat : ' +
            String(mins).padStart(2, '0') + ' dk : ' +
            String(secs).padStart(2, '0') + ' sn';
        }
      }, 1000);
      activeIntervals.push(intervalId);
    });
  }

  // NFR-20: Uzun süreli açık kalan sekmelerde JS Heap bellek sızıntısını (memory leak) önlemek için temizlik
  window.addEventListener('beforeunload', () => {
    while (activeIntervals.length > 0) {
      clearInterval(activeIntervals.pop());
    }
  });

  document.addEventListener('DOMContentLoaded', initCountdowns);
})();
