<?php
declare(strict_types=1);
chdir(dirname(__DIR__));
require_once dirname(__DIR__) . '/index.php';
