<?php
declare(strict_types=1);

namespace Martello\Tests;

require_once __DIR__ . '/../index.php';

use Throwable;

echo "========================================================================\n";
echo "MARTELLO 2. ASAMA: JSON VERI DEPOSU, TASARIM DESENLERI VE IS KURALLARI TESTI\n";
echo "========================================================================\n\n";

$passed = 0;
$failed = 0;

function assertCondition(bool $condition, string $testName): void {
    global $passed, $failed;
    if ($condition) {
        echo "[BASARILI] {$testName}\n";
        $passed++;
    } else {
        echo "[HATALI]   {$testName}\n";
        $failed++;
    }
}

// TEST 1: JSON Veri Deposu 20 Koleksiyon Doğrulaması
$allData = $dataStore->getAllData();
assertCondition(
    isset($allData['users'], $allData['wallets'], $allData['lots'], $allData['bids'], $allData['proxyBids'], $allData['auditLogs']),
    "1. JSON Veri Deposu (storage/martello_datastore.json) ve tüm tablolar yüklendi."
);

// TEST 2: Strategy Deseni (Kur Dönüşümü FR-21)
$usdStrategy = $controller->resolveCurrencyStrategy('USD');
$converted   = $usdStrategy->convertFromTry(34500.00, ['USD' => 34.50]);
assertCondition($converted === 1000.00, "2. Strategy Deseni (ICurrencyStrategy): 34.500 TRY -> 1.000 USD kur dönüşümü doğrulandı.");

// TEST 3: Canlı Pey Verme, Emanet Bloke Çözümü ve Otomatik Proxy Bidding (FR-13, FR-23, NFR-24)
// Lot #1001 mevcut en yüksek teklif: 65.000 TRY (Alıcı #3 Zeynep D., Proxy Tavan: 75.000 TRY, Min Artış: 2.500 TRY)
// Alıcı #6 (Emre K.) 67.500 TRY teklif verdiğinde sistem otomatik olarak Alıcı #3 adına 70.000 TRY karşı pey üretmelidir.
$bidResult = $auctionService->placeBid(1001, 6, 67500.00, '192.168.1.100');
assertCondition(
    $bidResult['status'] === 'SUCCESS' &&
    $bidResult['autoProxyResponse'] !== null &&
    (float) $bidResult['updatedLot']['mevcutEnYuksekTeklif'] === 70000.00 &&
    (int) $bidResult['updatedLot']['liderAliciId'] === 3,
    "3. Strategy + Observer + Proxy Bidding (NFR-24): 67.500 TRY manuel teklife karşılık sistem otomatik 70.000 TRY karşı pey üretti."
);

// TEST 4: Shill Bidding (Satıcının kendi ürününe pey vermesi - R-04) Engelleme Testi
$shillBlocked = false;
try {
    $auctionService->placeBid(1001, 2, 75000.00, '10.0.0.1'); // Kullanıcı #2 Satıcı Mehmet Kaya
} catch (Throwable $e) {
    $shillBlocked = true;
}
assertCondition($shillBlocked === true, "4. Güvenlik Kuralı (R-04): Satıcının kendi ürününe teklif vermesi (Shill Bidding) engellendi.");

// TEST 5: WORM Denetim İzi (Audit Log) SHA-256 Hash Zincirleme Doğrulaması (FR-25, NFR-11, R-12)
$updatedData = $dataStore->getAllData();
$logs        = $updatedData['auditLogs'];
$lastLog     = end($logs);
$prevLog     = $logs[count($logs) - 2];
assertCondition(
    $lastLog['prevHash'] === $prevLog['currentHash'] && strlen($lastLog['currentHash']) === 64,
    "5. WORM Denetim İzi (FR-25 & R-12): SHA-256 kriptografik hash zinciri (prevHash -> currentHash) doğrulandı."
);

echo "\n------------------------------------------------------------------------\n";
echo "TOPLAM SONUC: {$passed} Basarili, {$failed} Hatali.\n";
echo "========================================================================\n";
exit($failed > 0 ? 1 : 0);
