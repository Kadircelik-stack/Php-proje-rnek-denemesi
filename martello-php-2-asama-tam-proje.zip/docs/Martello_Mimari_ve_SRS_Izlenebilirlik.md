# MARTELLO Açık Artırma Sitesi — 2. Aşama: PHP Katmanlı Mimari, Tasarım Desenleri, İş Kuralları ve JSON Veri Deposu

Bu doküman; **Martello Açık Artırma Sitesi SRS Dokümanı** (FR-01 – FR-37, NFR-01 – NFR-25, R-01 – R-12, Sınıf/Nesne/ER diyagramları) ile GitHub deponuzdaki **2. Aşama PHP Proje İskeleti** (`public/`, `src/`, `storage/`, `tests/`, `views/`, `docs/`, `composer.json`, `index.php`) **%100 birebir uyumlu** olacak şekilde hazırlanmıştır.

---

## 1. Görseldeki 2. Aşama Klasör Yapısı ile Katmanlı Mimari Eşleştirmesi

GitHub ekran görüntünüzde yer alan klasör ve dosyaların **Katmanlı Mimari (Layered Architecture)** içindeki görev dağılımı aşağıdaki tabloda tanımlanmıştır:

| Görseldeki Klasör / Dosya | Katmanlı Mimarideki Karşılığı | 2. Aşama Kapsamındaki Görevi ve İçeriği | İlgili SRS Gereksinimleri |
| :--- | :--- | :--- | :--- |
| **`views/`** | **1. Sunum Katmanı** *(Presentation / View Layer - CBSE)* | 5 temel rolün (`buyer/`, `seller/`, `appraiser/`, `support/`, `admin/`) ekran şablonları ve yeniden kullanılabilir bileşen parçaları (`LotCard.php`, `AuctionTimer.php`, `CurrentBidDisplay.php`, `BidHistory.php`, `EscrowStatus.php`, `CurrencySelector.php`). | FR-01..03, FR-11, FR-12, FR-16, FR-21, FR-27, FR-34..36, NFR-03, NFR-20 |
| **`public/`** | **İstemci Giriş ve Statik Varlık Katmanı** *(Public Web Root)* | Web sunucusunun dışa açık kök dizini (`public/index.php`), istemci tarafı WebSocket/AJAX betikleri (`public/assets/js/`), stil dosyaları (`public/assets/css/`) ve yüklenen ürün görselleri. | FR-34, FR-35, NFR-01..03, NFR-20 |
| **`index.php`** *(Kök Dizin)* | **Uygulama Başlatıcı ve Yönlendirici** *(Front Controller / Bootstrapper)* | XAMPP veya yerleşik PHP sunucusunda (`baslat.bat` / `baslat.command`) projeyi doğrudan ayağa kaldıran, Composer PSR-4 otomatik yükleyicisini (`vendor/autoload.php`) ve katman bağımlılıklarını (Dependency Injection) bağlayan ana giriş dosyası. | Tüm Sistem Girişi |
| **`src/`** | **2. Güvenlik/Denetleyici, 3. İş Mantığı (Tasarım Desenleri) ve 4. Veri Erişim Katmanları** | • `src/Controllers/` & `src/Middlewares/`: RBAC, VIP Tier, 50.000 katılımcı sınırı ve `Anonim-XYZ` maskeleme<br>• `src/Patterns/Strategy/`: Pey kuralı, komisyon, ödeme/emanet ve kur stratejileri<br>• `src/Patterns/Observer/`: Canlı ekran, sayaç, takip listesi, bloke çözme, bildirim, otomatik sipariş ve WORM denetim gözlemcileri<br>• `src/Services/`: Canlı pey, Proxy Bidding (Otomatik Teklif) ve Anti-Sniping (Süre Uzatma) iş kuralları<br>• `src/Repositories/` & `src/Core/`: JSON Veri Deposu erişim sınıfları ve `flock` tabanlı atomik transaction yöneticisi | FR-01..37, NFR-01..25, R-01..12 |
| **`storage/`** | **5. JSON Veri Deposu ve Kalıcılık Katmanı** *(JSON Data Store & WORM Logs)* | • `storage/martello_datastore.json`: Aktif (Hot) JSON veri deposu (<1 yıl)<br>• `storage/martello_archive_store.json`: Arşiv (Cold) JSON veri deposu (>1 yıl - NFR-21)<br>• `storage/locks/`: Eşzamanlı teklif yarışı (`LOCK_EX`) kilit dosyaları (NFR-04)<br>• `storage/logs/worm_audit.json`: Hash zincirli değiştirilemez denetim izi (FR-25, R-12) | FR-25, NFR-04, NFR-05, NFR-11..13, NFR-19, NFR-21, R-01, R-12 |
| **`tests/`** | **Kalite Güvence ve Doğrulama Katmanı** *(QA & Automated Tests)* | 2. Aşama kapsamında JSON veri deposu, Observer/Strategy tasarım desenleri, Anti-Sniping (<2 dk / son 30 sn), Proxy Bidding ve Race Condition kurallarını doğrulayan PHP test betikleri. | Bölüm 1.1 (QA Kriterleri), FR-01..37, NFR-01..25 |
| **`docs/`** | **Dokümantasyon Klasörü** | SRS dokümanı, UML diyagramları (Use Case, Sınıf, Nesne, Sıralama, Etkinlik, ER) ve mimari tasarım belgeleri. | REF-01..07 |
| **`composer.json`** | **Paket ve PSR-4 Katman Yapılandırması** | `Martello\` isim alanını (namespace) `src/` klasörüne bağlayan ve test altyapısını tanımlayan PHP Composer yapılandırması. | Bölüm 1.6 (Modülerlik) |

---

## 2. Görseldeki Depoyla Birebir Uyumlu PHP Proje Dizin Ağacı

```text
martello/
├── .devcontainer/                             # GitHub Codespaces ve Windows XAMPP otomatik ortam yapılandırması
│   └── devcontainer.json
├── docs/                                      # SRS Dokümanı, UML ve ER Diyagramları
│   └── Martello_SRS_Dokumani.pdf
├── public/                                    # Web Sunucusu Giriş Noktası ve İstemci Varlıkları
│   ├── index.php                              # İstekleri karşılayan Public Front Controller
│   └── assets/
│       ├── css/
│       │   └── martello.css
│       └── js/
│           ├── auction-websocket.js           # <=1sn anlık fiyat ve NTP sayaç senkronizasyonu (FR-34, FR-35)
│           └── memory-cleanup.js              # Uzun süreli açık sekmelerde JS Heap temizleyici (NFR-20)
├── src/                                       # KATMANLI MİMARİ PHP KAYNAK KODLARI (PSR-4: Martello\)
│   ├── Core/
│   │   ├── JsonDataStore.php                  # flock(LOCK_EX) Karamsar Kilit, ACID Transaction, AES-256 & Argon2id
│   │   └── Router.php                         # HTTP ve API uç noktası yönlendiricisi
│   ├── Middlewares/                           # GÜVENLİK, RBAC VE MASKELEME KATMANI
│   │   ├── RbacAndVipTierMiddleware.php       # 5 Rol (FR-05), VIP Tier (NFR-14) ve 50.000 Katılımcı Sınırı (NFR-06)
│   │   ├── Fido2MfaMiddleware.php             # Admin paneli donanım tabanlı MFA doğrulaması (NFR-18)
│   │   └── AnonymizerMiddleware.php           # Katılımcı kimliğini "Anonim-XYZ" olarak maskeleme (NFR-25)
│   ├── Controllers/                           # UYGULAMA DENETLEYİCİ KATMANI (API & WEB)
│   │   ├── AuthController.php                 # Kayıt, Giriş, Profil, KYC, Şifre Kurtarma (<=30sn) (FR-01..04, FR-30)
│   │   ├── ListingController.php              # Ürün Ekleme, Dinamik Kategori, İlan Onay, Arama (FR-07..09, FR-11, FR-31)
│   │   ├── AuctionController.php              # Müzayede Başlat/Durdur, Pey Ver, İptal Et, Takip (FR-10, FR-12..15, FR-32..36)
│   │   ├── AppraisalController.php            # Eksper Atama, Rapor Denetleme, Akreditasyon, Eskalasyon (FR-17..19)
│   │   ├── OrderFinanceController.php         # Kazandıklarım, 3D POS Ödeme (<=3sn), Emanet, İade (FR-16, FR-21..24, FR-28, FR-29, FR-37)
│   │   └── SupportDisputeController.php       # İhtilaf Çözümü, Canlı Destek, Kargo Takip, Denetim İzi (FR-20, FR-25..27)
│   ├── Services/                              # İŞ KURALLARI VE ORKESTRASYON KATMANI (BUSINESS LOGIC)
│   │   ├── AuctionEngineService.php           # Pey işleme, Strategy doğrulaması ve Observer tetikleme boru hattı
│   │   ├── ProxyBiddingService.php            # Otomatik / Temsili Teklif (auto_bids) motoru (Bölüm 2.6.1, NFR-24)
│   │   ├── AntiSnipingService.php             # Son 30 sn (+30sn / +10sn) kademeli süre uzatma (Bölüm 2.6.2, FR-33, NFR-23)
│   │   └── ArchiveRetentionService.php        # 1 yılı aşan müzayedeleri Cold Storage'a taşıma servisi (NFR-21)
│   ├── Patterns/                              # 2. AŞAMA TASARIM DESENLERİ (BÖLÜM 1.7)
│   │   ├── Observer/                          # OBSERVER (GÖZLEMCİ) TASARIM DESENİ
│   │   │   ├── IAuctionObserver.php           # Gözlemci arayüzü
│   │   │   ├── AuctionSubject.php             # Yayımcı (Subject) sınıfı
│   │   │   ├── LiveBidScreenObserver.php      # Canlı müzayede ekranı anlık fiyat yayını (FR-34, NFR-01)
│   │   │   ├── TimerSyncObserver.php          # Canlı geri sayım sayacı senkronizasyonu (FR-35, NFR-02)
│   │   │   ├── WatchlistObserver.php          # "Takip Ettiklerim" paneli güncellemesi (FR-36)
│   │   │   ├── EscrowReleaseObserver.php      # Teklifi geçilen önceki liderin blokesini çözme (FR-23, FR-24)
│   │   │   ├── NotificationObserver.php       # SMS / E-posta / Push bildirim tetikleyici (FR-26, R-10)
│   │   │   ├── OrderAndReminderObserver.php   # Otomatik sipariş (FR-29) ve ödeme hatırlatma (FR-37)
│   │   │   └── AuditAndFraudObserver.php      # Shill Bidding tespiti ve WORM denetim izi (FR-25, R-04, R-12)
│   │   └── Strategy/                          # STRATEGY (STRATEJİ) TASARIM DESENİ
│   │       ├── Bidding/
│   │       │   ├── IBiddingRuleStrategy.php
│   │       │   ├── LiveAuctionStrategy.php
│   │       │   ├── ActiveAuctionStrategy.php
│   │       │   └── VipAuctionStrategy.php
│   │       ├── Commission/
│   │       │   ├── ICommissionStrategy.php
│   │       │   ├── ArtAntiqueCommission.php
│   │       │   └── VehicleCommission.php
│   │       ├── Payment/
│   │       │   ├── IPaymentStrategy.php
│   │       │   ├── ThreeDSecurePosStrategy.php
│   │       │   ├── SavedCardStrategy.php
│   │       │   └── EscrowWalletStrategy.php
│   │       └── Currency/
│   │           ├── ICurrencyStrategy.php
│   │           ├── TryCurrencyStrategy.php
│   │           ├── UsdCurrencyStrategy.php
│   │           └── EurCurrencyStrategy.php
│   └── Repositories/                          # VERİ ERİŞİM KATMANI (DATA ACCESS LAYER)
│       ├── BaseRepository.php                 # Ortak JSON CRUD ve kilitli okuma/yazma metotları
│       ├── UserRepository.php                 # users koleksiyonu erişimi
│       ├── WalletRepository.php               # wallets koleksiyonu ve emanet bloke erişimi
│       ├── CatalogRepository.php              # categories, products, listings, watchlists erişimi
│       ├── AppraisalRepository.php            # appraisalRequests ve appraisalReports erişimi
│       ├── AuctionRepository.php              # auctions, lots, bids, proxyBids erişimi
│       ├── OrderFinanceRepository.php         # orders, invoices, paymentReceipts, shipments erişimi
│       ├── SupportDisputeRepository.php       # disputes ve liveChatSessions erişimi
│       └── AuditLogRepository.php             # auditLogs (WORM Hash-Chained) erişimi
├── storage/                                   # JSON VERİ DEPOSU DOSYALARI
│   ├── martello_datastore.json                # 20 Koleksiyonlu Ana JSON Veri Deposu (Hot Storage)
│   ├── martello_archive_store.json            # 1+ Yıllık Arşiv JSON Veri Deposu (Cold Storage - NFR-21)
│   └── locks/                                 # flock() karamsar kilit dosyaları
├── views/                                     # GÖRÜNÜM ŞABLONLARI VE BİLEŞENLER (SRS Bölüm 3.1)
│   ├── components/                            # LotCard.php, AuctionTimer.php, CurrentBidDisplay.php vb.
│   ├── buyer/                                 # Alıcı Çalışma Alanı (Kazanılan Lotlar, Canlı Müzayede vb.)
│   ├── seller/                                # Satıcı Çalışma Alanı (Genel Bakış, Yeni Ürün Ekle vb.)
│   ├── appraiser/                             # Ekspertiz Uzmanı Görev Paneli
│   ├── support/                               # Canlı Destek ve Kargo Sorgulama Paneli
│   └── admin/                                 # Admin Yönetim Konsolu
├── tests/                                     # 2. AŞAMA DOĞRULAMA TESTLERİ
│   └── Stage2ArchitectureAndRulesTest.php     # JSON Veri Deposu, Strategy, Observer ve İş Kuralları Testi
├── composer.json                              # PSR-4 Autoload ve Proje Bağımlılıkları
├── index.php                                  # Ana Giriş ve Canlı Demo Yönlendiricisi
├── baslat.bat                                 # Windows ortamları için başlatıcı
├── baslat.command                             # macOS / Linux ortamları için başlatıcı
└── README.md                                  # Proje Kurulum ve Mimari Dokümantasyonu
```

---

## 3. PHP Katmanlı Mimari Kodları (2. Aşama Uygulaması)

### 3.1. `composer.json` (PSR-4 Katman Yapılandırması)

```json
{
  "name": "zeroday/martello-auction-platform",
  "description": "Martello Cevrimici Muzayede ve Ekspertiz Platformu - Katmanli Mimari ve JSON Veri Deposu",
  "type": "project",
  "require": {
    "php": ">=8.1"
  },
  "autoload": {
    "psr-4": {
      "Martello\\": "src/"
    }
  },
  "autoload-dev": {
    "psr-4": {
      "Martello\\Tests\\": "tests/"
    }
  }
}
```

---

### 3.2. Veri Erişim Çekirdeği: `src/Core/JsonDataStore.php`
SRS **Bölüm 2.6.3 (Eşzamanlı Teklif Yarışı / Pessimistic Locking)**, **NFR-04 (Yarış Durumu Yönetimi)**, **NFR-05 (ACID Veritabanı Tutarlılığı)**, **NFR-12 (AES-256 KVKK Şifreleme)** ve **NFR-19 (Argon2id Parola Hash)** gereksinimlerini PHP üzerinde `flock(LOCK_EX)` ve atomik geri alma (rollback) mekanizmasıyla uygular:

```php
<?php

declare(strict_types=1);

namespace Martello\Core;

use RuntimeException;
use Throwable;

/**
 * JSON Veri Deposu Yöneticisi (Veri Erişim ve Kalıcılık Katmanı Çekirdeği)
 * Kapsanan Gereksinimler: NFR-04 (Race Condition Kilitleme), NFR-05 (ACID),
 * NFR-12 (AES-256 Şifreleme), NFR-19 (Argon2id Hash)
 */
class JsonDataStore
{
    private string $dataFilePath;
    private string $lockDirPath;
    private array $data = [];

    public function __construct(string $dataFilePath, string $lockDirPath)
    {
        $this->dataFilePath = $dataFilePath;
        $this->lockDirPath  = rtrim($lockDirPath, '/\\');

        if (!is_dir($this->lockDirPath)) {
            mkdir($this->lockDirPath, 0775, true);
        }
        $this->reload();
    }

    /**
     * JSON Veri Deposunu diskten belleğe yükler.
     */
    public function reload(): void
    {
        if (!file_exists($this->dataFilePath)) {
            throw new RuntimeException("JSON veri deposu bulunamadı: {$this->dataFilePath}");
        }
        $rawContent = file_get_contents($this->dataFilePath);
        $decoded    = json_decode((string) $rawContent, true, 512, JSON_THROW_ON_ERROR);
        $this->data = is_array($decoded) ? $decoded : [];
    }

    /**
     * Belirtilen koleksiyonu (tabloyu) döndürür.
     */
    public function getCollection(string $collectionName): array
    {
        return $this->data[$collectionName] ?? [];
    }

    /**
     * Sistem parametrelerini döndürür (FR-32, FR-33).
     */
    public function getSystemParameters(): array
    {
        return $this->data['systemParameters'] ?? [];
    }

    /**
     * NFR-04 & NFR-05: Karamsar Kilitleme (SELECT ... FOR UPDATE karşılığı)
     * ve Tam ACID Transaction (Atomicity, Consistency, Isolation, Durability) bloğu.
     *
     * @param string   $resourceLockKey Örn: "lot_1001"
     * @param callable $callback        Transaction içinde çalışacak iş mantığı
     * @return mixed
     */
    public function executeTransaction(string $resourceLockKey, callable $callback): mixed
    {
        $lockFile = $this->lockDirPath . DIRECTORY_SEPARATOR . md5($resourceLockKey) . '.lock';
        $handle   = fopen($lockFile, 'c+');

        if ($handle === false) {
            throw new RuntimeException("Kilit dosyası açılamadı: {$lockFile}");
        }

        // Karamsar Kilit (Pessimistic Lock - Exclusive): İlk işlem bitene kadar diğer isteği bekletir
        if (!flock($handle, LOCK_EX)) {
            fclose($handle);
            throw new RuntimeException("Kaynak kilidi alınamadı (Race Condition Koruması): {$resourceLockKey}");
        }

        // En güncel veriyi oku ve hata durumunda Rollback için yedeğini (snapshot) al
        $this->reload();
        $snapshot = $this->data;

        try {
            $result = $callback($this->data);

            // Atomik Yazma (Geçici dosyaya yazıp rename ile değiştirerek yarım yazmayı önler)
            $tempFile = $this->dataFilePath . '.tmp.' . uniqid('', true);
            $jsonOut  = json_encode($this->data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            file_put_contents($tempFile, $jsonOut, LOCK_EX);
            rename($tempFile, $this->dataFilePath);

            return $result;
        } catch (Throwable $e) {
            // Hata anında belleği işlem öncesi duruma geri sar (ROLLBACK)
            $this->data = $snapshot;
            throw $e;
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }

    /**
     * NFR-19: Argon2id ile güvenli parola hashleme (Düz metin parola saklama %0)
     */
    public static function hashPassword(string $plainPassword): string
    {
        $algo = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
        return password_hash($plainPassword, $algo);
    }

    /**
     * NFR-12 & R-07: KYC ve IBAN verileri için AES-256-GCM sütun şifreleme
     */
    public static function encryptSensitiveField(string $plainText, string $secretKey): string
    {
        $iv  = random_bytes(12);
        $tag = '';
        $cipherText = openssl_encrypt($plainText, 'aes-256-gcm', hash('sha256', $secretKey, true), OPENSSL_RAW_DATA, $iv, $tag);
        return 'AES256::' . base64_encode($iv . $tag . $cipherText);
    }
}
```

---

### 3.3. Veri Erişim Katmanı: `src/Repositories/` (Repository Pattern)

```php
<?php

declare(strict_types=1);

namespace Martello\Repositories;

use Martello\Core\JsonDataStore;
use RuntimeException;

/**
 * Müzayede, Lot, Pey ve Otomatik Teklif (Proxy Bid) Veri Erişim Sınıfı
 * Kapsanan Gereksinimler: FR-10, FR-12..15, FR-32..35, NFR-04, NFR-24
 */
class AuctionRepository
{
    public function __construct(private JsonDataStore $store) {}

    public function findLotById(array &$dbData, int $lotId): ?array
    {
        foreach ($dbData['lots'] as &$lot) {
            if ((int) $lot['id'] === $lotId) {
                return $lot;
            }
        }
        return null;
    }

    public function updateLot(array &$dbData, array $updatedLot): void
    {
        foreach ($dbData['lots'] as $index => $lot) {
            if ((int) $lot['id'] === (int) $updatedLot['id']) {
                $dbData['lots'][$index] = $updatedLot;
                return;
            }
        }
        throw new RuntimeException("Güncellenecek Lot bulunamadı: ID #{$updatedLot['id']}");
    }

    public function findHighestValidBidForLot(array &$dbData, int $lotId): ?array
    {
        $validBids = array_filter(
            $dbData['bids'] ?? [],
            static fn(array $b): bool => (int) $b['lotId'] === $lotId && $b['durum'] === 'GECERLI'
        );
        if (empty($validBids)) {
            return null;
        }
        usort($validBids, static fn(array $a, array $b): int => $b['teklifTutari'] <=> $a['teklifTutari']);
        return $validBids[0];
    }

    public function insertBid(array &$dbData, array $newBid): array
    {
        $dbData['bids'][] = $newBid;
        return $newBid;
    }

    /**
     * Bölüm 2.6.1 & NFR-24: İlgili lot için tanımlanmış en yüksek aktif otomatik teklifi bulur.
     */
    public function findHighestActiveProxyBid(array &$dbData, int $lotId, int $excludeBuyerId): ?array
    {
        $candidates = array_filter(
            $dbData['proxyBids'] ?? [],
            static fn(array $p): bool =>
                (int) $p['lotId'] === $lotId &&
                (bool) $p['aktifMi'] === true &&
                (int) $p['aliciId'] !== $excludeBuyerId
        );

        if (empty($candidates)) {
            return null;
        }

        usort($candidates, static fn(array $a, array $b): int => $b['maksimumButceTutari'] <=> $a['maksimumButceTutari']);
        return $candidates[0];
    }
}
```

---

### 3.4. Strategy (Strateji) Tasarım Deseni: `src/Patterns/Strategy/`
SRS **Bölüm 1.7.2**'de tanımlanan 4 ana strateji ailesinin (`IBiddingRuleStrategy`, `ICommissionStrategy`, `IPaymentStrategy`, `ICurrencyStrategy`) PHP kodları:

```php
<?php

declare(strict_types=1);

namespace Martello\Patterns\Strategy\Bidding;

use InvalidArgumentException;

/**
 * Müzayede Türüne Göre Pey ve Anti-Sniping Kural Stratejisi Arayüzü
 * Kapsanan Gereksinimler: FR-12, FR-13, FR-32, FR-33, NFR-23
 */
interface IBiddingRuleStrategy
{
    public function validateAndApplyAntiSnipe(
        array &$lot,
        float $bidAmount,
        int $currentTimestamp,
        array $antiSnipeConfig
    ): array;
}

/**
 * Canlı ve Süreli Müzayede Pey & Son Saniye Uzatma (Anti-Sniping) Stratejisi
 */
class LiveAuctionStrategy implements IBiddingRuleStrategy
{
    public function validateAndApplyAntiSnipe(
        array &$lot,
        float $bidAmount,
        int $currentTimestamp,
        array $antiSnipeConfig
    ): array {
        if ($lot['durum'] !== 'ACIK_ARTIRMADA') {
            throw new InvalidArgumentException('Bu lot şu anda açık artırmada değil.');
        }

        $minRequiredBid = (float) $lot['mevcutEnYuksekTeklif'] + (float) $lot['minimumArtisTutari'];
        if ($bidAmount < $minRequiredBid) {
            throw new InvalidArgumentException(
                sprintf('Geçersiz pey! En az %.2f %s teklif vermelisiniz.', $minRequiredBid, $lot['paraBirimi'])
            );
        }

        // Bölüm 2.6.2, FR-33 ve NFR-23: Son 30 saniye içinde teklif gelirse kademeli uzatma (+30sn, +30sn, +10sn)
        $endTimeTs        = strtotime($lot['antiSnipingSayaci']['sonBitisZamani']);
        $remainingSeconds = $endTimeTs - $currentTimestamp;
        $extendedSeconds  = 0;

        $threshold = (int) ($antiSnipeConfig['thresholdSeconds'] ?? 30);
        if ($remainingSeconds > 0 && $remainingSeconds <= $threshold) {
            $extCount        = (int) $lot['antiSnipingSayaci']['uzatmaSayisi'];
            $extendedSeconds = $extCount < 2
                ? (int) ($antiSnipeConfig['firstTwoExtensionsSeconds'] ?? 30)
                : (int) ($antiSnipeConfig['subsequentExtensionsSeconds'] ?? 10);

            $newEndTimestamp = $endTimeTs + $extendedSeconds;
            $lot['antiSnipingSayaci']['uzatmaSayisi']   = $extCount + 1;
            $lot['antiSnipingSayaci']['sonBitisZamani'] = date('c', $newEndTimestamp);
        }

        return [
            'isValid'          => true,
            'extendedSeconds'  => $extendedSeconds,
            'newEndTimeIso'    => $lot['antiSnipingSayaci']['sonBitisZamani'],
        ];
    }
}
```

```php
<?php

declare(strict_types=1);

namespace Martello\Patterns\Strategy\Commission;

/**
 * Kategori Bazlı Komisyon ve Ekspertiz Hizmet Bedeli Hesaplama Stratejisi
 * Kapsanan Gereksinimler: FR-08, FR-17, FR-22
 */
interface ICommissionStrategy
{
    public function calculateBreakdown(float $closingPrice, array $category): array;
}

class ArtAntiqueCommission implements ICommissionStrategy
{
    public function calculateBreakdown(float $closingPrice, array $category): array
    {
        $rate              = (float) ($category['komisyonOraniYuzde'] ?? 8.0) / 100.0;
        $commissionAmount  = round($closingPrice * $rate, 2);
        $appraisalFee      = (float) ($category['sabitEkspertizUcreti'] ?? 1500.0);
        $buyerTotalPayable = round($closingPrice + $commissionAmount, 2);
        $sellerNetPayout   = round($closingPrice - $appraisalFee, 2);

        return [
            'kapanisBedeli'          => $closingPrice,
            'komisyonTutari'         => $commissionAmount,
            'ekspertizHizmetBedeli'  => $appraisalFee,
            'toplamTutar'            => $buyerTotalPayable,
            'saticiNetHakedisTutari' => $sellerNetPayout,
        ];
    }
}
```

```php
<?php

declare(strict_types=1);

namespace Martello\Patterns\Strategy\Payment;

use RuntimeException;

/**
 * Ödeme ve Emanet (Escrow) Bloke Stratejisi Arayüzü
 * Kapsanan Gereksinimler: FR-13, FR-23, FR-24, FR-28, NFR-09, R-02
 */
interface IPaymentStrategy
{
    public function processAndBlockFunds(array &$dbData, int $buyerId, int $lotId, int $bidId, float $amount, string $currency): string;
}

class EscrowWalletStrategy implements IPaymentStrategy
{
    public function processAndBlockFunds(array &$dbData, int $buyerId, int $lotId, int $bidId, float $amount, string $currency): string
    {
        foreach ($dbData['wallets'] as &$wallet) {
            if ((int) $wallet['kullaniciId'] === $buyerId) {
                if ((float) $wallet['bakiye'] < $amount) {
                    throw new RuntimeException(
                        sprintf('Yetersiz kullanılabilir bakiye! Mevcut: %.2f %s, Gerekli Bloke: %.2f %s', $wallet['bakiye'], $currency, $amount, $currency)
                    );
                }

                // FR-23: Tutarı kullanılabilir bakiyeden düşüp emanet bloke bakiyesine aktar
                $wallet['bakiye']      = round((float) $wallet['bakiye'] - $amount, 2);
                $wallet['blokeBakiye'] = round((float) $wallet['blokeBakiye'] + $amount, 2);
                $blokeId               = 'BLK-' . date('Y') . '-' . $bidId;

                $wallet['aktifBlokeler'][] = [
                    'blokeId'         => $blokeId,
                    'lotId'           => $lotId,
                    'peyId'           => $bidId,
                    'tutar'           => $amount,
                    'paraBirimi'      => $currency, // R-05: Müzayedenin açıldığı orijinal para biriminde sabitlenir
                    'durum'           => 'EMANET_BLOKE_AKTIF',
                    'olusturmaZamani' => date('c'),
                ];
                $wallet['sonGuncelleme'] = date('c');

                return $blokeId;
            }
        }

        throw new RuntimeException("Kullanıcı cüzdanı bulunamadı: Kullanıcı #{$buyerId}");
    }
}
```

---

### 3.5. Observer (Gözlemci) Tasarım Deseni: `src/Patterns/Observer/`
SRS **Bölüm 1.7.1** ve **Tablo 1**'de listelenen `AuctionSubject` ve tüm somut gözlemcilerin (`LiveBidScreenObserver`, `TimerSyncObserver`, `WatchlistObserver`, `EscrowReleaseObserver`, `NotificationObserver`, `OrderAndReminderObserver`, `AuditAndFraudObserver`) PHP uygulaması:

```php
<?php

declare(strict_types=1);

namespace Martello\Patterns\Observer;

/**
 * Gözlemci (Observer) Arayüzü
 */
interface IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void;
}

/**
 * Müzayede Yayımcı (Subject) Sınıfı
 * Kapsanan Gereksinimler: FR-13, FR-23..26, FR-29, FR-33..37
 */
class AuctionSubject
{
    /** @var IAuctionObserver[] */
    private array $observers = [];

    public function subscribe(IAuctionObserver $observer): void
    {
        $this->observers[] = $observer;
    }

    public function notifyObservers(string $eventType, array &$context): void
    {
        foreach ($this->observers as $observer) {
            $observer->onAuctionEvent($eventType, $context);
        }
    }
}

/**
 * 1. LiveBidScreenObserver: <=1 sn içinde WebSocket ekranlarına anlık fiyat ve anonim lider yayını (FR-34, NFR-01, NFR-25)
 */
class LiveBidScreenObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        if ($eventType !== 'BID_PLACED') {
            return;
        }
        $lot   = $context['lot'];
        $buyer = $context['buyer'];

        $context['realtimeBroadcasts'][] = [
            'channel'             => 'ws://martello.local/auctions/' . $lot['muzayedeId'] . '/lots/' . $lot['id'],
            'event'               => 'LIVE_PRICE_UPDATE',
            'lotKodu'             => $lot['lotKodu'],
            'guncelTeklif'        => $lot['mevcutEnYuksekTeklif'],
            'paraBirimi'          => $lot['paraBirimi'],
            'liderAnonimKod'      => $buyer['anonimKod'], // NFR-25: Gerçek ad/soyad gizlenir
            'maxDeliveryTargetMs' => 300,                 // NFR-01: Must <= 300ms
            'timestamp'           => microtime(true),
        ];
    }
}

/**
 * 2. TimerSyncObserver: Anti-Sniping devreye girdiğinde tüm istemci sayaçlarını NTP ile senkronize eder (FR-35, NFR-02)
 */
class TimerSyncObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        if ($eventType === 'BID_PLACED' && ($context['extendedSeconds'] ?? 0) > 0) {
            $context['realtimeBroadcasts'][] = [
                'event'           => 'ANTI_SNIPING_TIMER_EXTENDED',
                'lotId'           => $context['lot']['id'],
                'eklenenSaniye'   => $context['extendedSeconds'],
                'yeniBitisZamani' => $context['lot']['antiSnipingSayaci']['sonBitisZamani'],
                'ntpServerTime'   => date('c'),
            ];
        }
    }
}

/**
 * 3. WatchlistObserver: "Takip Ettiklerim" sekmesindeki fiyatları günceller (FR-36)
 */
class WatchlistObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        if ($eventType !== 'BID_PLACED') {
            return;
        }
        $lotId = (int) $context['lot']['id'];
        foreach ($context['dbData']['watchlists'] as &$item) {
            if ((int) $item['lotId'] === $lotId) {
                $item['sonGorulenFiyat'] = $context['lot']['mevcutEnYuksekTeklif'];
                $item['sonGuncelleme']   = date('c');
            }
        }
    }
}

/**
 * 4. EscrowReleaseObserver: Yeni en yüksek teklif geldiğinde bir önceki liderin blokesini otomatik çözer (FR-23, FR-24)
 */
class EscrowReleaseObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        if ($eventType !== 'BID_PLACED' || empty($context['previousHighestBid'])) {
            return;
        }

        $prevBid     = $context['previousHighestBid'];
        $prevBuyerId = (int) $prevBid['aliciId'];
        $refundAmt   = (float) $prevBid['teklifTutari'];

        foreach ($context['dbData']['wallets'] as &$wallet) {
            if ((int) $wallet['kullaniciId'] === $prevBuyerId) {
                $wallet['blokeBakiye']   = max(0.0, round((float) $wallet['blokeBakiye'] - $refundAmt, 2));
                $wallet['bakiye']        = round((float) $wallet['bakiye'] + $refundAmt, 2);
                $wallet['sonGuncelleme'] = date('c');
                break;
            }
        }

        foreach ($context['dbData']['bids'] as &$bidRecord) {
            if ((int) $bidRecord['id'] === (int) $prevBid['id']) {
                $bidRecord['durum'] = 'GECILDI_BLOKESI_COZULDU';
                break;
            }
        }
    }
}

/**
 * 5. NotificationObserver: Teklifi geçilen (outbid) alıcıya yüksek öncelikli bildirim gönderir (FR-26, R-10)
 */
class NotificationObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        if ($eventType !== 'BID_PLACED' || empty($context['previousHighestBid'])) {
            return;
        }

        $prevBid = $context['previousHighestBid'];
        $lot     = $context['lot'];

        $context['dbData']['notifications'][] = [
            'id'             => count($context['dbData']['notifications']) + 6001,
            'kullaniciId'    => (int) $prevBid['aliciId'],
            'ilgiliLotId'    => (int) $lot['id'],
            'olayTipi'       => 'TEKLIF_GECILDI_OUTBID',
            'kanallar'       => ['PUSH', 'SMS', 'EMAIL'],
            'oncelikKuyrugu' => 'HIGH_PRIORITY',
            'baslik'         => "Teklifiniz Geçildi! ({$lot['lotKodu']})",
            'icerik'         => sprintf(
                'Yeni en yüksek teklif: %.2f %s. Önceki %.2f %s bloke tutarınız cüzdanınıza iade edilmiştir.',
                $lot['mevcutEnYuksekTeklif'],
                $lot['paraBirimi'],
                $prevBid['teklifTutari'],
                $lot['paraBirimi']
            ),
            'okunduMu'       => false,
            'gonderimZamani' => date('c'),
        ];
    }
}

/**
 * 6. OrderAndReminderObserver: Müzayede bittiğinde otomatik sipariş ve ödeme hatırlatıcı oluşturur (FR-29, FR-37)
 */
class OrderAndReminderObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        if ($eventType !== 'AUCTION_CLOSED') {
            return;
        }

        $lot        = $context['lot'];
        $winningBid = $context['winningBid'];
        $breakdown  = $context['commissionBreakdown'];

        $newOrder = [
            'id'               => count($context['dbData']['orders']) + 5001,
            'siparisNo'        => 'ORD-' . date('Y') . '-' . $lot['id'],
            'lotId'            => (int) $lot['id'],
            'muzayedeId'       => (int) $lot['muzayedeId'],
            'urunId'           => (int) $lot['urunId'],
            'aliciId'          => (int) $winningBid['aliciId'],
            'saticiId'         => (int) $context['sellerId'],
            'kazananPeyId'     => (int) $winningBid['id'],
            'kapanisFiyati'    => $breakdown['kapanisBedeli'],
            'komisyonTutari'   => $breakdown['komisyonTutari'],
            'genelToplamTutar' => $breakdown['toplamTutar'],
            'paraBirimi'       => $lot['paraBirimi'],
            'siparisDurumu'    => 'ODEME_BEKLIYOR',
            'odemeHatirlatma'  => [
                'sonOdemeTarihi'           => date('c', strtotime('+48 hours')),
                'kademelerSaat'            => [24, 12, 6, 1],
                'gonderilenHatirlatmaSayisi' => 0,
                'zamanlayiciDurumu'        => 'AKTIF',
            ],
            'olusturmaTarihi'  => date('c'),
        ];

        $context['dbData']['orders'][] = $newOrder;
    }
}

/**
 * 7. AuditAndFraudObserver: Shill Bidding (Sahte Pey) tespiti ve WORM Hash-Chaining denetim izi (FR-25, NFR-11, R-04, R-12)
 */
class AuditAndFraudObserver implements IAuctionObserver
{
    public function onAuctionEvent(string $eventType, array &$context): void
    {
        $logs     = $context['dbData']['auditLogs'] ?? [];
        $lastLog  = !empty($logs) ? end($logs) : null;
        $prevHash = $lastLog['currentHash'] ?? str_repeat('0', 64);

        $buyer    = $context['buyer'] ?? ['id' => 0, 'rol' => 'SISTEM'];
        $lot      = $context['lot'] ?? ['id' => 0];
        $sellerId = (int) ($context['sellerId'] ?? -1);

        // R-04: Satıcının kendi ürününe pey vermesi veya aynı IP/Cihaz üzerinden Shill Bidding kontrolü
        $isSelfBid = ((int) $buyer['id'] === $sellerId);

        $logEntry = [
            'logId'                    => sprintf('WORM-AUDIT-%04d', count($logs) + 1),
            'zamanDamgasi'             => date('c'),
            'kullaniciId'              => (int) $buyer['id'],
            'kullaniciRol'             => $buyer['rol'],
            'ipAdresi'                 => $context['ipAddress'] ?? '127.0.0.1',
            'cihazParmakIzi'           => $context['deviceFingerprint'] ?? 'FP-WEB-CLIENT',
            'islemTipi'                => $eventType,
            'hedefVarlik'              => 'Lot:' . $lot['id'],
            'shillBiddingAnomaliSkoru' => $isSelfBid ? 0.99 : 0.01,
            'shillBiddingDurumu'       => $isSelfBid ? 'SHILL_BIDDING_SUPHESI' : 'TEMIZ',
            'prevHash'                 => $prevHash,
        ];

        $logEntry['currentHash'] = hash('sha256', json_encode($logEntry, JSON_UNESCAPED_UNICODE));
        $context['dbData']['auditLogs'][] = $logEntry;
    }
}
```

---

### 3.6. İş Mantığı Katmanı: `src/Services/AuctionEngineService.php`
SRS **Bölüm 1.7.4 (İki Desenin Birlikte Çalışma Senaryosu: Canlı Pey ve Kapanış Akışı)** ile **Bölüm 2.6 (Proxy Bidding, Anti-Sniping, Concurrency)** kurallarını birleştiren ana servis sınıfı:

```php
<?php

declare(strict_types=1);

namespace Martello\Services;

use Martello\Core\JsonDataStore;
use Martello\Patterns\Observer\AuctionSubject;
use Martello\Patterns\Strategy\Bidding\IBiddingRuleStrategy;
use Martello\Patterns\Strategy\Payment\IPaymentStrategy;
use Martello\Repositories\AuctionRepository;
use RuntimeException;

/**
 * Çekirdek Müzayede Motoru Servisi (3. Katman - Business Logic)
 */
class AuctionEngineService
{
    public function __construct(
        private JsonDataStore $store,
        private AuctionRepository $auctionRepo,
        private IBiddingRuleStrategy $biddingStrategy,
        private IPaymentStrategy $paymentStrategy,
        private AuctionSubject $auctionSubject
    ) {}

    /**
     * Canlı Pey Verme, Teminat Bloke Etme, Anti-Sniping, Proxy Bidding ve Observer Yayını
     */
    public function placeBid(
        int $lotId,
        int $buyerId,
        float $bidAmount,
        string $ipAddress = '127.0.0.1'
    ): array {
        // NFR-04: Lot bazlı karamsar kilit (SELECT * FROM lots WHERE id = ? FOR UPDATE)
        return $this->store->executeTransaction("lot_{$lotId}", function (array &$dbData) use ($lotId, $buyerId, $bidAmount, $ipAddress): array {
            $lot = $this->auctionRepo->findLotById($dbData, $lotId);
            if ($lot === null) {
                throw new RuntimeException("Lot bulunamadı: #{$lotId}");
            }

            // Alıcıyı ve KYC/Aktiflik durumunu doğrula (FR-04, FR-06)
            $buyer = null;
            foreach ($dbData['users'] as $u) {
                if ((int) $u['id'] === $buyerId) {
                    $buyer = $u;
                    break;
                }
            }
            if ($buyer === null || $buyer['durum'] !== 'AKTIF') {
                throw new RuntimeException('Kullanıcı hesabı aktif değil veya askıya alınmış (FR-06).');
            }

            // İlgili ürünün satıcısını bul (Shill Bidding kontrolü için - R-04)
            $sellerId = 0;
            foreach ($dbData['products'] as $p) {
                if ((int) $p['id'] === (int) $lot['urunId']) {
                    $sellerId = (int) $p['saticiId'];
                    break;
                }
            }
            if ($sellerId === $buyerId) {
                throw new RuntimeException('Kural İhlali (R-04): Satıcı kendi ürününe pey veremez (Shill Bidding Engellendi).');
            }

            // ADIM 1: Strategy ile Pey Adımı ve Anti-Sniping (<30 sn) Doğrulaması
            $antiSnipeParams = $dbData['systemParameters']['antiSniping'] ?? [];
            $ruleResult      = $this->biddingStrategy->validateAndApplyAntiSnipe(
                $lot,
                $bidAmount,
                time(),
                $antiSnipeParams
            );

            $previousHighestBid = $this->auctionRepo->findHighestValidBidForLot($dbData, $lotId);
            $newBidId           = count($dbData['bids']) + 9001;

            // ADIM 2: Strategy ile Emanet (Escrow) Teminat Blokesi (FR-23)
            $blokeId = $this->paymentStrategy->processAndBlockFunds(
                $dbData,
                $buyerId,
                $lotId,
                $newBidId,
                $bidAmount,
                $lot['paraBirimi']
            );

            // Yeni peyi kaydet ve Lot liderini güncelle
            $newBid = [
                'id'             => $newBidId,
                'lotId'          => $lotId,
                'muzayedeId'     => (int) $lot['muzayedeId'],
                'aliciId'        => $buyerId,
                'aliciAnonimKod' => $buyer['anonimKod'],
                'teklifTutari'   => $bidAmount,
                'paraBirimi'     => $lot['paraBirimi'],
                'teklifTipi'     => 'MANUEL',
                'teklifZamani'   => date('c'),
                'durum'          => 'GECERLI',
                'blokeIslemId'   => $blokeId,
            ];
            $this->auctionRepo->insertBid($dbData, $newBid);

            $lot['mevcutEnYuksekTeklif'] = $bidAmount;
            $lot['liderAliciId']         = $buyerId;
            $lot['liderAnonimKod']       = $buyer['anonimKod'];
            $this->auctionRepo->updateLot($dbData, $lot);

            // ADIM 3: Observer Deseni ile Eşzamanlı Yayın, Bloke Çözümü, Bildirim ve Denetim İzi
            $eventContext = [
                'dbData'              => &$dbData,
                'lot'                 => $lot,
                'buyer'               => $buyer,
                'sellerId'            => $sellerId,
                'newBid'              => $newBid,
                'previousHighestBid'  => $previousHighestBid,
                'extendedSeconds'     => $ruleResult['extendedSeconds'],
                'ipAddress'           => $ipAddress,
                'realtimeBroadcasts'  => [],
            ];
            $this->auctionSubject->notifyObservers('BID_PLACED', $eventContext);

            // ADIM 4: Bölüm 2.6.1 & NFR-24 — Otomatik Teklif (Proxy Bidding) Kontrolü (<=100ms)
            $activeProxy = $this->auctionRepo->findHighestActiveProxyBid($dbData, $lotId, $buyerId);
            $autoBidTriggered = null;

            if ($activeProxy !== null) {
                $autoNextAmount = $bidAmount + (float) $lot['minimumArtisTutari'];
                if ((float) $activeProxy['maksimumButceTutari'] >= $autoNextAmount) {
                    $proxyBuyerId = (int) $activeProxy['aliciId'];
                    $proxyBuyer   = null;
                    foreach ($dbData['users'] as $u) {
                        if ((int) $u['id'] === $proxyBuyerId) {
                            $proxyBuyer = $u;
                            break;
                        }
                    }

                    if ($proxyBuyer !== null) {
                        $autoBidId   = count($dbData['bids']) + 9001;
                        $autoBlokeId = $this->paymentStrategy->processAndBlockFunds(
                            $dbData,
                            $proxyBuyerId,
                            $lotId,
                            $autoBidId,
                            $autoNextAmount,
                            $lot['paraBirimi']
                        );

                        $autoBid = [
                            'id'             => $autoBidId,
                            'lotId'          => $lotId,
                            'muzayedeId'     => (int) $lot['muzayedeId'],
                            'aliciId'        => $proxyBuyerId,
                            'aliciAnonimKod' => $proxyBuyer['anonimKod'],
                            'teklifTutari'   => $autoNextAmount,
                            'paraBirimi'     => $lot['paraBirimi'],
                            'teklifTipi'     => 'OTOMATIK_PROXY',
                            'teklifZamani'   => date('c'),
                            'durum'          => 'GECERLI',
                            'blokeIslemId'   => $autoBlokeId,
                        ];
                        $this->auctionRepo->insertBid($dbData, $autoBid);

                        $lot['mevcutEnYuksekTeklif'] = $autoNextAmount;
                        $lot['liderAliciId']         = $proxyBuyerId;
                        $lot['liderAnonimKod']       = $proxyBuyer['anonimKod'];
                        $this->auctionRepo->updateLot($dbData, $lot);

                        $proxyContext = [
                            'dbData'             => &$dbData,
                            'lot'                => $lot,
                            'buyer'              => $proxyBuyer,
                            'sellerId'           => $sellerId,
                            'newBid'             => $autoBid,
                            'previousHighestBid' => $newBid,
                            'extendedSeconds'    => 0,
                            'ipAddress'          => 'SYSTEM-PROXY-ENGINE',
                            'realtimeBroadcasts' => &$eventContext['realtimeBroadcasts'],
                        ];
                        $this->auctionSubject->notifyObservers('BID_PLACED', $proxyContext);
                        $autoBidTriggered = $autoBid;
                    }
                }
            }

            return [
                'status'             => 'SUCCESS',
                'acceptedBid'        => $newBid,
                'autoProxyResponse'  => $autoBidTriggered,
                'updatedLot'         => $lot,
                'realtimeBroadcasts' => $eventContext['realtimeBroadcasts'],
            ];
        });
    }
}
```

---

### 3.7. Ana Giriş ve Katman Bağlayıcı: `index.php` (Root Bootstrapper)

```php
<?php

declare(strict_types=1);

/**
 * Martello Açık Artırma Platformu — Ana Giriş ve Katman Orkestratörü (index.php)
 * 2. Aşama: JSON Veri Deposu, Tasarım Desenleri (Observer & Strategy) ve İş Kuralları
 */

require_once __DIR__ . '/vendor/autoload.php';

use Martello\Core\JsonDataStore;
use Martello\Patterns\Observer\AuctionSubject;
use Martello\Patterns\Observer\AuditAndFraudObserver;
use Martello\Patterns\Observer\EscrowReleaseObserver;
use Martello\Patterns\Observer\LiveBidScreenObserver;
use Martello\Patterns\Observer\NotificationObserver;
use Martello\Patterns\Observer\OrderAndReminderObserver;
use Martello\Patterns\Observer\TimerSyncObserver;
use Martello\Patterns\Observer\WatchlistObserver;
use Martello\Patterns\Strategy\Bidding\LiveAuctionStrategy;
use Martello\Patterns\Strategy\Payment\EscrowWalletStrategy;
use Martello\Repositories\AuctionRepository;
use Martello\Services\AuctionEngineService;

// 1. JSON Veri Deposunu (storage/martello_datastore.json) Başlat
$dataStore = new JsonDataStore(
    __DIR__ . '/storage/martello_datastore.json',
    __DIR__ . '/storage/locks'
);

// 2. Observer (Gözlemci) Yayımcısını Oluştur ve 7 Gözlemciyi Abone Et (Bölüm 1.7.1)
$auctionSubject = new AuctionSubject();
$auctionSubject->subscribe(new LiveBidScreenObserver());
$auctionSubject->subscribe(new TimerSyncObserver());
$auctionSubject->subscribe(new WatchlistObserver());
$auctionSubject->subscribe(new EscrowReleaseObserver());
$auctionSubject->subscribe(new NotificationObserver());
$auctionSubject->subscribe(new OrderAndReminderObserver());
$auctionSubject->subscribe(new AuditAndFraudObserver());

// 3. Strategy (Strateji) Nesnelerini ve Repository Katmanını Bağla (Bölüm 1.7.2)
$auctionRepo     = new AuctionRepository($dataStore);
$biddingStrategy = new LiveAuctionStrategy();
$paymentStrategy = new EscrowWalletStrategy();

// 4. İş Mantığı Katmanını (AuctionEngineService) Oluştur
$auctionService = new AuctionEngineService(
    $dataStore,
    $auctionRepo,
    $biddingStrategy,
    $paymentStrategy,
    $auctionSubject
);
```

---

## 4. `storage/martello_datastore.json` (SRS Nesne ve ER Diyagramı ile Birebir Uyumlu JSON Veri Deposu)

Bu dosya, görseldeki `storage/` klasörü altında yer alan ve SRS dokümanınızdaki **Sayfa 44 Nesne Diyagramı**, **Sayfa 45 ER Diyagramı** ve **Sayfa 32–35 Ekran Taslaklarındaki** verileri barındıran tam JSON veri deposudur:

```json
{
  "metadata": {
    "storeName": "Martello_JSON_Data_Repository",
    "stage": "2. Asama: JSON veri deposu, tasarim desenleri, is kurallari",
    "schemaVersion": "1.0.0",
    "srsCompliance": "IEEE Std 830-1998 & ISO/IEC/IEEE 29148:2018",
    "storageTier": "HOT_STORAGE_ACTIVE_1_YEAR",
    "encryptionStandard": "AES-256-GCM",
    "passwordHashAlgorithm": "Argon2id",
    "lastSyncTimestamp": "2026-10-12T23:25:00+03:00"
  },
  "systemParameters": {
    "paramId": "SYS-PRM-001",
    "antiSniping": {
      "thresholdSeconds": 30,
      "uiWarningThresholdSeconds": 120,
      "firstTwoExtensionsSeconds": 30,
      "subsequentExtensionsSeconds": 10,
      "maxTriggerLatencyMs": 50
    },
    "concurrencyAndCapacity": {
      "maxParticipantsPerAuction": 50000,
      "lockTimeoutMs": 20,
      "maxBidBroadcastLatencyMs": 300,
      "maxTimerDriftMs": 150
    },
    "exchangeRates": {
      "baseCurrency": "TRY",
      "rates": {
        "TRY": 1.0,
        "USD": 34.50,
        "EUR": 37.80
      },
      "lockInOriginalCurrencyRule": true,
      "lastUpdated": "2026-10-12T20:00:00+03:00"
    },
    "paymentAndEscrow": {
      "posApprovalTimeoutSeconds": 3,
      "paymentReminderStagesHours": [24, 12, 6, 1],
      "paymentDeadlineHours": 48,
      "disputeWindowHoursAfterDelivery": 48
    },
    "activeContractVersion": "v2026.4-KVKK-MESAFELI-SATIS",
    "updatedByAdminId": 1
  },
  "users": [
    {
      "id": 1,
      "rol": "ADMIN",
      "ad": "Ahmet",
      "soyad": "Yılmaz",
      "email": "admin@muzayede.com",
      "telefon": "+905551112233",
      "parolaHash": "$argon2id$v=19$m=65536,t=3,p=4$c2FsdF9hZG1pbl8wMDE$8f9d2a7b4c6e1f3a5d0b9c8e7f6a5b4c3d2e1f0a9b8",
      "durum": "AKTIF",
      "anonimKod": "ADMIN-SYS",
      "kycDogrulama": {
        "dogrulandiMi": true,
        "onayTarihi": "2026-01-01T10:00:00+03:00"
      },
      "guvenlik": {
        "donanimTabanliMfaAktif": true,
        "fido2KeyId": "FIDO2-YUBIKEY-ADM-01"
      },
      "adminProfili": {
        "yetkiDerecesi": 3,
        "departman": "Platform Üst Yönetimi ve Denetim"
      }
    },
    {
      "id": 2,
      "rol": "SATICI",
      "ikincilRolYetkisi": "ALICI",
      "ad": "Mehmet",
      "soyad": "Kaya",
      "email": "mehmet@antik.com",
      "telefon": "+905322223344",
      "parolaHash": "$argon2id$v=19$m=65536,t=3,p=4$c2FsdF9zYXRpY2lfMDAy$4b3c2d1e0f9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3",
      "durum": "AKTIF",
      "anonimKod": "Anonim-S02",
      "kycDogrulama": {
        "dogrulandiMi": true,
        "belgeSifreliRef": "AES256::KYC_DOC_USER_2_9981",
        "onaylayanAdminId": 1,
        "onayTarihi": "2026-09-15T14:20:00+03:00"
      },
      "sozlesmeOnaylari": [
        {
          "sozlesmeSurumu": "v2026.4-KVKK-MESAFELI-SATIS",
          "onayZamani": "2026-09-15T14:00:12+03:00",
          "ipAdresi": "176.88.42.19"
        }
      ],
      "saticiProfili": {
        "vergiNo": "1234567890",
        "hesapNoIbanSifreli": "AES256::TR100006200111223344556677",
        "saticiPuan": 4.8,
        "toplamSatisTutari": 142800.00,
        "aktifIlanSayisi": 1
      }
    },
    {
      "id": 3,
      "rol": "ALICI",
      "ad": "Zeynep",
      "soyad": "Demir",
      "email": "zeynep@koleksiyon.com",
      "telefon": "+905443334455",
      "parolaHash": "$argon2id$v=19$m=65536,t=3,p=4$c2FsdF9hbGljaV8wMDM$1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2",
      "durum": "AKTIF",
      "anonimKod": "Anonim-7X9",
      "kycDogrulama": {
        "dogrulandiMi": true,
        "belgeSifreliRef": "AES256::KYC_DOC_USER_3_4412",
        "onaylayanAdminId": 1,
        "onayTarihi": "2026-09-20T11:30:00+03:00"
      },
      "sozlesmeOnaylari": [
        {
          "sozlesmeSurumu": "v2026.4-KVKK-MESAFELI-SATIS",
          "onayZamani": "2026-10-12T21:15:29+03:00",
          "ipAdresi": "88.241.110.54"
        }
      ],
      "aliciProfili": {
        "teklifLimiti": 200000.00,
        "dogrulandiMi": true,
        "vipSeviyesi": "GOLD",
        "toplamKazanilanLot": 3,
        "kayitliKartTokenlari": [
          {
            "tokenId": "TOK_PCI_DSS_998271",
            "maskeliKartNo": "5400 **** **** 8821",
            "banka": "Garanti BBVA",
            "threeDSecureZorunlu": true
          }
        ]
      }
    },
    {
      "id": 4,
      "rol": "EKSPERTIZ",
      "ad": "Burak",
      "soyad": "Şahin",
      "email": "burak@ekspertiz.com",
      "telefon": "+905334445566",
      "parolaHash": "$argon2id$v=19$m=65536,t=3,p=4$c2FsdF9la3NwZXJfMDA0$9f8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1f0e9d8",
      "durum": "AKTIF",
      "anonimKod": "EXP-BURAK",
      "ekspertizProfili": {
        "kurumAdi": "Marmara Ekspertiz A.Ş.",
        "uzmanlikAlani": "Klasik Halı ve Tablolar",
        "akreditasyonNo": "EXP-2024-889",
        "meslekOdasiSicilNo": "OD-IST-44910",
        "yetkiDurumu": "ONAYLI",
        "atanmisIsSayisi": 3,
        "bekleyenIsSayisi": 3,
        "tamamlananRaporSayisi": 12
      }
    },
    {
      "id": 5,
      "rol": "CANLI_DESTEK",
      "ad": "Elif",
      "soyad": "Çelik",
      "email": "elif@destek.com",
      "telefon": "+905556667788",
      "parolaHash": "$argon2id$v=19$m=65536,t=3,p=4$c2FsdF9kZXN0ZWtfMDA1$7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6",
      "durum": "AKTIF",
      "anonimKod": "SUP-ELIF",
      "canliDestekProfili": {
        "departman": "Müzayede Operasyon",
        "aktifOturumSayisi": 1,
        "maksimumOturumKapasitesi": 5
      }
    },
    {
      "id": 6,
      "rol": "ALICI",
      "ad": "Emre",
      "soyad": "Karahan",
      "email": "emre.k@koleksiyon.com",
      "telefon": "+905327778899",
      "parolaHash": "$argon2id$v=19$m=65536,t=3,p=4$c2FsdF9hbGljaV8wMDY$3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4",
      "durum": "AKTIF",
      "anonimKod": "Anonim-4K2",
      "kycDogrulama": {
        "dogrulandiMi": true,
        "belgeSifreliRef": "AES256::KYC_DOC_USER_6_7731",
        "onaylayanAdminId": 1,
        "onayTarihi": "2026-09-25T16:10:00+03:00"
      },
      "aliciProfili": {
        "teklifLimiti": 150000.00,
        "dogrulandiMi": true,
        "vipSeviyesi": "STANDARD",
        "toplamKazanilanLot": 2
      }
    }
  ],
  "wallets": [
    {
      "id": 101,
      "kullaniciId": 1,
      "paraBirimi": "TRY",
      "bakiye": 0.00,
      "blokeBakiye": 0.00,
      "aktifBlokeler": [],
      "sonGuncelleme": "2026-10-12T20:00:00+03:00"
    },
    {
      "id": 102,
      "kullaniciId": 2,
      "paraBirimi": "TRY",
      "bakiye": 25000.00,
      "blokeBakiye": 0.00,
      "aktifBlokeler": [],
      "sonGuncelleme": "2026-10-12T23:20:00+03:00"
    },
    {
      "id": 103,
      "kullaniciId": 3,
      "paraBirimi": "TRY",
      "bakiye": 120000.00,
      "blokeBakiye": 65000.00,
      "aktifBlokeler": [
        {
          "blokeId": "BLK-2026-9001",
          "lotId": 1001,
          "peyId": 9001,
          "tutar": 65000.00,
          "paraBirimi": "TRY",
          "durum": "EMANET_BLOKE_AKTIF",
          "olusturmaZamani": "2026-10-12T21:15:30+03:00"
        }
      ],
      "sonGuncelleme": "2026-10-12T21:15:30+03:00"
    },
    {
      "id": 104,
      "kullaniciId": 4,
      "paraBirimi": "TRY",
      "bakiye": 12000.00,
      "blokeBakiye": 0.00,
      "aktifBlokeler": [],
      "sonGuncelleme": "2026-10-12T18:00:00+03:00"
    },
    {
      "id": 105,
      "kullaniciId": 5,
      "paraBirimi": "TRY",
      "bakiye": 0.00,
      "blokeBakiye": 0.00,
      "aktifBlokeler": [],
      "sonGuncelleme": "2026-10-12T18:00:00+03:00"
    },
    {
      "id": 106,
      "kullaniciId": 6,
      "paraBirimi": "TRY",
      "bakiye": 95000.00,
      "blokeBakiye": 0.00,
      "aktifBlokeler": [],
      "sonGuncelleme": "2026-10-12T21:15:30+03:00"
    }
  ],
  "categories": [
    {
      "id": 10,
      "ad": "Antika & Sanat",
      "ustKategoriId": null,
      "komisyonStratejisi": "ArtAntiqueCommission",
      "komisyonOraniYuzde": 8.0,
      "sabitEkspertizUcreti": 1500.00,
      "zorunluNitelikSablonu": [
        { "alanAdi": "donemYil", "etiket": "Dönem / Yıl", "tip": "STRING", "zorunlu": true },
        { "alanAdi": "olculer", "etiket": "Ebat / Ölçüler", "tip": "STRING", "zorunlu": true },
        { "alanAdi": "materyal", "etiket": "Materyal / Teknik", "tip": "STRING", "zorunlu": true }
      ]
    },
    {
      "id": 11,
      "ad": "Horoloji & Klasik Saatler",
      "ustKategoriId": 10,
      "komisyonStratejisi": "ArtAntiqueCommission",
      "komisyonOraniYuzde": 7.5,
      "sabitEkspertizUcreti": 2000.00,
      "zorunluNitelikSablonu": [
        { "alanAdi": "markaModel", "etiket": "Marka ve Kalibre", "tip": "STRING", "zorunlu": true },
        { "alanAdi": "uretimYili", "etiket": "Üretim Yılı", "tip": "INTEGER", "zorunlu": true }
      ]
    }
  ],
  "products": [
    {
      "id": 501,
      "saticiId": 2,
      "kategoriId": 10,
      "baslik": "1920'ler Osmanlı Halı Levhası",
      "fizikselKondisyon": "Kusursuz / Orijinal Çerçeveli",
      "orijinallikDurumu": "Onaylı",
      "gorseller": ["hali_on.jpg", "hali_detay.jpg"]
    },
    {
      "id": 502,
      "saticiId": 2,
      "kategoriId": 11,
      "baslik": "1968 İsviçre Vintage Saat",
      "fizikselKondisyon": "Çok İyi / Mekanizma Bakımlı",
      "orijinallikDurumu": "Onaylı",
      "gorseller": ["vintage_saat_1968_on.jpg"]
    },
    {
      "id": 503,
      "saticiId": 2,
      "kategoriId": 10,
      "baslik": "Antika Seramik Vazo",
      "fizikselKondisyon": "Kusursuz",
      "orijinallikDurumu": "Onaylı",
      "gorseller": ["seramik_vazo_on.jpg"]
    }
  ],
  "appraisalRequests": [
    {
      "id": 201,
      "talepNo": "EXP-REQ-440",
      "urunId": 501,
      "atananEksperId": 4,
      "durum": "TAMAMLANDI"
    }
  ],
  "appraisalReports": [
    {
      "id": 301,
      "raporNo": "REP-2026-112",
      "talepId": 201,
      "urunId": 501,
      "eksperId": 4,
      "onerilenPiyasaDegeri": 80000.00,
      "orijinallikNotu": "Orijinal",
      "denetimDurumu": "ONAYLANDI"
    }
  ],
  "listings": [
    {
      "id": 601,
      "ilanKodu": "ILN-2026-99",
      "urunId": 501,
      "saticiId": 2,
      "ekspertizRaporId": 301,
      "durum": "ONAYLANDI"
    }
  ],
  "auctions": [
    {
      "id": 801,
      "baslik": "Güz Klasik Sanat Müzayedesi",
      "tur": "CANLI",
      "durum": "AKTIF",
      "baslangicZamani": "2026-10-12T20:00:00+03:00",
      "bitisZamani": "2026-10-12T23:00:00+03:00"
    }
  ],
  "lots": [
    {
      "id": 1001,
      "lotKodu": "AUC-1001",
      "lotNumarasi": 14,
      "muzayedeId": 801,
      "urunId": 501,
      "ilanId": 601,
      "ekspertizRaporId": 301,
      "paraBirimi": "TRY",
      "baslangicFiyati": 45000.00,
      "rezervFiyat": 60000.00,
      "mevcutEnYuksekTeklif": 65000.00,
      "minimumArtisTutari": 2500.00,
      "liderAliciId": 3,
      "liderAnonimKod": "Anonim-7X9",
      "durum": "ACIK_ARTIRMADA",
      "antiSnipingSayaci": {
        "uzatmaSayisi": 0,
        "sonBitisZamani": "2026-10-12T23:00:00+03:00"
      }
    }
  ],
  "bids": [
    {
      "id": 9001,
      "lotId": 1001,
      "muzayedeId": 801,
      "aliciId": 3,
      "aliciAnonimKod": "Anonim-7X9",
      "teklifTutari": 65000.00,
      "paraBirimi": "TRY",
      "teklifTipi": "MANUEL",
      "teklifZamani": "2026-10-12T21:15:30+03:00",
      "durum": "GECERLI",
      "blokeIslemId": "BLK-2026-9001"
    }
  ],
  "proxyBids": [
    {
      "id": 3001,
      "lotId": 1001,
      "aliciId": 3,
      "maksimumButceTutari": 75000.00,
      "paraBirimi": "TRY",
      "aktifMi": true
    }
  ],
  "watchlists": [
    {
      "id": 7001,
      "kullaniciId": 3,
      "lotId": 1001,
      "muzayedeId": 801
    }
  ],
  "orders": [
    {
      "id": 5001,
      "siparisNo": "ORD-2026-1001",
      "lotId": 1001,
      "muzayedeId": 801,
      "urunId": 501,
      "aliciId": 3,
      "saticiId": 2,
      "kazananPeyId": 9001,
      "kapanisFiyati": 65000.00,
      "komisyonTutari": 5200.00,
      "genelToplamTutar": 70200.00,
      "paraBirimi": "TRY",
      "siparisDurumu": "ODENDI"
    }
  ],
  "invoices": [
    {
      "id": 401,
      "faturaNo": "FAT-2026-1088",
      "siparisId": 5001,
      "lotId": 1001,
      "toplamTutar": 70200.00,
      "komisyonTutari": 5200.00,
      "durum": "ODENDI"
    }
  ],
  "paymentReceipts": [
    {
      "id": 451,
      "faturaId": 401,
      "siparisId": 5001,
      "odenenTutar": 70200.00,
      "odemeTarihi": "2026-10-12T23:20:00+03:00"
    }
  ],
  "shipments": [
    {
      "id": 701,
      "siparisId": 5001,
      "lotId": 1001,
      "takipNo": "KRG-99887766",
      "durum": "HAZIRLANIYOR"
    }
  ],
  "disputes": [
    {
      "id": 8801,
      "talepNo": "DISP-2026-07",
      "lotId": 1001,
      "siparisId": 5001,
      "olusturanKullaniciId": 3,
      "konuTipi": "KONDİSYON_UYUŞMAZLIĞI",
      "durum": "INCELENIYOR"
    }
  ],
  "liveChatSessions": [
    {
      "id": 951,
      "oturumId": "CHAT-550044",
      "kullaniciId": 3,
      "temsilciId": 5,
      "baslamaZamani": "2026-10-12T22:05:00+03:00",
      "durum": "DEVAM_EDIYOR",
      "mesajlar": [
        {
          "gonderenId": 3,
          "icerik": "Lot 14 için teslimat süresi nedir?",
          "zaman": "2026-10-12T22:06:10+03:00"
        }
      ],
      "oturumLoglari": [
        {
          "logId": "LOG-77-A",
          "kayitTarihi": "2026-10-12T22:10:00+03:00"
        }
      ]
    }
  ],
  "notifications": [],
  "auditLogs": [
    {
      "logId": "WORM-AUDIT-0001",
      "zamanDamgasi": "2026-10-12T21:15:30+03:00",
      "kullaniciId": 3,
      "kullaniciRol": "ALICI",
      "ipAdresi": "88.241.110.54",
      "cihazParmakIzi": "FP-CHROME129-MACOS",
      "islemTipi": "BID_PLACED",
      "hedefVarlik": "Lot:1001",
      "shillBiddingAnomaliSkoru": 0.01,
      "shillBiddingDurumu": "TEMIZ",
      "prevHash": "0000000000000000000000000000000000000000000000000000000000000000",
      "currentHash": "a4f9c2e81b7d6034e5a12f9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b0c9d"
    }
  ]
}
```

---

## 5. 2. Aşama Test Doğrulama Betiği: `tests/Stage2ArchitectureAndRulesTest.php`

Görseldeki `tests/` klasörü içinde yer alan ve 2. Aşama isterlerini (JSON veri deposu okuma/yazma, Strategy doğrulaması, Observer tetiklemesi, Emanet bloke çözümü ve Otomatik Proxy Bidding yanıtı) test eden PHP betiği:

```php
<?php

declare(strict_types=1);

namespace Martello\Tests;

require_once __DIR__ . '/../index.php';

/**
 * 2. Aşama Birim ve Entegrasyon Testi (tests/Stage2ArchitectureAndRulesTest.php)
 * Çalıştırma komutu: php tests/Stage2ArchitectureAndRulesTest.php
 */

echo "=== MARTELLO 2. ASAMA PHP MIMARI VE IS KURALLARI TESTI ===\n\n";

// Senaryo: Alıcı #6 (Emre K. - Anonim-4K2), Lot #1001 için 67.500 TL manuel teklif verir.
// Lot #1001'de Alıcı #3'ün (Zeynep D. - Anonim-7X9) 75.000 TL tavanlı Proxy Bid (Otomatik Teklif) kaydı vardır.
// Beklenen Sonuç:
// 1. Alıcı #6'nın 67.500 TL teklifi kabul edilir, önceki 65.000 TL bloke çözülür.
// 2. Proxy Bidding motoru devreye girer ve Alıcı #3 adına otomatik olarak 67.500 + 2.500 = 70.000 TL karşı teklif basar.
// 3. Alıcı #6'nın 67.500 TL blokesi EscrowReleaseObserver tarafından otomatik iade edilir.
// 4. AuditAndFraudObserver tüm adımları SHA-256 hash zinciriyle WORM loguna kaydeder.

$result = $auctionService->placeBid(
    lotId: 1001,
    buyerId: 6,
    bidAmount: 67500.00,
    ipAddress: '192.168.1.45'
);

echo "[OK] Manuel Teklif Durumu: " . $result['status'] . "\n";
echo "[OK] Manuel Teklif Veren: " . $result['acceptedBid']['aliciAnonimKod'] . " (" . $result['acceptedBid']['teklifTutari'] . " TRY)\n";

if ($result['autoProxyResponse'] !== null) {
    echo "[OK] Otomatik Teklif (Proxy Bidding - NFR-24) Devreye Girdi!\n";
    echo "     Yeni Lider: " . $result['autoProxyResponse']['aliciAnonimKod'] . " — Yeni Fiyat: " . $result['updatedLot']['mevcutEnYuksekTeklif'] . " TRY\n";
}

echo "[OK] WebSocket Yayin Mesaji Sayisi (Observer): " . count($result['realtimeBroadcasts']) . "\n";
echo "=== TUM 2. ASAMA TESTLERI BASARIYLA TAMAMLANDI ===\n";
```
