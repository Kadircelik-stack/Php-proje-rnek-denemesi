<?php
/** @var array $db */
$chat = $db['liveChatSessions'][0];
?>
<div class="workspace-wrapper">
  <aside class="sidebar">
    <div class="sidebar-label">ÇALIŞMA ALANI (CANLI DESTEK)</div>
    <ul class="side-nav">
      <li><a href="#canli-sohbet" class="active">💬 Canlı sohbet (FR-27)</a></li>
      <li><a href="#kargo-takip">📦 Kargo teslimat takibi (Senaryo 9)</a></li>
    </ul>
  </aside>

  <main class="main-content">
    <?php if (!empty($flashMessage)): ?>
      <div class="alert-box"><?= htmlspecialchars($flashMessage['message']) ?></div>
    <?php endif; ?>

    <div class="workspace-header">
      <div class="sub-kicker">CANLI DESTEK / OPERASYONEL MÜŞTERİ TEMSİLCİSİ</div>
      <h1>Canlı Sohbet ve Kargo Takip Merkezi</h1>
      <p style="color:var(--text-muted);">Aktif Temsilci: Elif Çelik (Departman: Müzayede Operasyon — Oturum: <?= htmlspecialchars($chat['oturumId']) ?>)</p>
    </div>

    <div style="display:grid; grid-template-columns:1fr 1fr; gap:24px;">
      <div id="canli-sohbet" class="panel-card">
        <h3>Canlı Sohbet Oturumu: <?= htmlspecialchars($chat['oturumId']) ?> (Kullanıcı Hikayesi 4)</h3>
        <div style="background:#12100d; border:1px solid var(--border-subtle); border-radius:8px; padding:16px; margin:12px 0; max-height:260px; overflow-y:auto;">
          <?php foreach ($chat['mesajlar'] as $m): ?>
            <div style="margin-bottom:12px; padding-bottom:8px; border-bottom:1px solid #221e18;">
              <strong style="color:var(--gold-primary); font-size:0.84rem;"><?= htmlspecialchars($m['gonderenAd'] ?? ('Kullanıcı #' . $m['gonderenId'])) ?></strong>
              <span style="font-size:0.75rem; color:var(--text-muted); float:right;"><?= htmlspecialchars($m['zaman']) ?></span>
              <div style="margin-top:4px; font-size:0.9rem;"><?= htmlspecialchars($m['icerik']) ?></div>
            </div>
          <?php endforeach; ?>
        </div>
        <form method="POST" style="display:flex; gap:10px;">
          <input type="hidden" name="action" value="send_chat">
          <input type="hidden" name="sender_id" value="5">
          <input type="hidden" name="sender_name" value="Elif Ç. (Canlı Destek)">
          <input type="text" name="message" class="form-control" placeholder="Müşteriye yanıt yazın..." required>
          <button type="submit" class="gold-btn">Gönder</button>
        </form>
      </div>

      <div id="kargo-takip" class="panel-card">
        <h3>Kargo Teslimat Takibi ve Bilgilendirme (Kullanıcı Hikayesi 9 & R-03)</h3>
        <table class="martello-table" style="margin-top:12px;">
          <thead>
            <tr>
              <th>Takip No</th>
              <th>Lot Kodu</th>
              <th>Lojistik Firması</th>
              <th>Durum</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($db['shipments'] as $sh): ?>
              <tr>
                <td><code><?= htmlspecialchars($sh['takipNo']) ?></code></td>
                <td><strong><?= htmlspecialchars($sh['lotKodu']) ?></strong></td>
                <td><?= htmlspecialchars($sh['kargoFirmasi']) ?></td>
                <td><span class="badge badge-gold"><?= htmlspecialchars($sh['durum']) ?></span></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>
