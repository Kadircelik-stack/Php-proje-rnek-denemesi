<?php
/** @var array $db */
/** @var callable $formatPrice */
?>
<div class="workspace-wrapper">
  <aside class="sidebar">
    <div class="sidebar-label">ÇALIŞMA ALANI (EKSPERTİZ)</div>
    <ul class="side-nav">
      <li><a href="#gorev-paneli" class="active">📋 Görev paneli (FR-17)</a></li>
      <li><a href="#incelemeler">🔍 İncelemeler (FR-18)</a></li>
      <li><a href="#rapor-gecmisi">📜 Rapor geçmişi</a></li>
      <li><a href="#eskalasyon">⬆️ İtiraz & Eskalasyon (Senaryo 10)</a></li>
    </ul>
  </aside>

  <main class="main-content">
    <?php if (!empty($flashMessage)): ?>
      <div class="alert-box"><?= htmlspecialchars($flashMessage['message']) ?></div>
    <?php endif; ?>

    <div class="workspace-header">
      <div class="sub-kicker">EKSPERTİZ UZMANI / ÇALIŞMA ALANI</div>
      <h1>Görev paneli</h1>
      <p style="color:var(--text-muted);">Akredite Uzman: Burak Şahin (Marmara Ekspertiz A.Ş. — Sicil: EXP-2024-889)</p>
    </div>

    <!-- SRS SAYFA 35 KPI KARTLARI -->
    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">ATANMIŞ İŞLER</div>
        <div class="kpi-value"><?= count($db['appraisalRequests']) ?></div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">BEKLEYEN</div>
        <div class="kpi-value">3</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">RAPORLAR</div>
        <div class="kpi-value"><?= count($db['appraisalReports']) ?></div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">İTİRAZLAR</div>
        <div class="kpi-value"><?= count($db['disputes']) ?></div>
      </div>
    </div>

    <!-- SRS SAYFA 35 GÖREV KARTLARI (AUC-1042, AUC-1043, AUC-1044) -->
    <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:18px; margin-bottom:24px;">
      <?php foreach ($db['appraisalRequests'] as $req): ?>
        <?php
          $prodTitle = 'Koleksiyon Eseri';
          foreach ($db['products'] as $p) {
              if ((int)$p['id'] === (int)$req['urunId']) {
                  $prodTitle = $p['baslik'];
                  break;
              }
          }
        ?>
        <div class="panel-card" style="margin-bottom:0;">
          <div style="font-size:0.78rem; color:var(--gold-primary);"><?= htmlspecialchars($req['lotKodu']) ?> • <?= htmlspecialchars($req['talepNo']) ?></div>
          <h3 style="margin:6px 0;"><?= htmlspecialchars($prodTitle) ?></h3>
          <p style="font-size:0.84rem; color:var(--text-muted); margin-bottom:14px;"><?= htmlspecialchars($req['not']) ?></p>
          <span class="badge <?= $req['durum'] === 'TAMAMLANDI' ? 'badge-green' : 'badge-gold' ?>"><?= htmlspecialchars($req['durum']) ?></span>
        </div>
      <?php endforeach; ?>
    </div>

    <div id="incelemeler" class="panel-card">
      <h3>Ekspertiz Raporu Oluştur veya Üst Birime Eskale Et (FR-18 & Kullanıcı Hikayesi 2, 10)</h3>
      <form method="POST">
        <input type="hidden" name="action" value="submit_appraisal">
        <div class="form-grid">
          <div>
            <label style="font-size:0.8rem; color:var(--text-muted);">İncelenen Görev Bileti (Ticket):</label>
            <select name="request_id" class="form-control">
              <?php foreach ($db['appraisalRequests'] as $req): ?>
                <option value="<?= (int)$req['id'] ?>"><?= htmlspecialchars($req['talepNo'] . ' (' . $req['lotKodu'] . ')') ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label style="font-size:0.8rem; color:var(--text-muted);">Önerilen Piyasa Değeri (TRY):</label>
            <input type="number" name="suggested_value" value="55000" class="form-control" required>
          </div>
          <div>
            <label style="font-size:0.8rem; color:var(--text-muted);">Fiziksel Kondisyon ve Orijinallik Rapor Notu:</label>
            <input type="text" name="note" value="Fiziksel kondisyon, dönem materyali ve seri numarası %100 orijinaldir." class="form-control" required>
          </div>
        </div>
        <div style="margin-top:14px; display:flex; gap:14px; align-items:center;">
          <button type="submit" class="gold-btn">Rapor oluştur (FR-18)</button>
          <label style="font-size:0.85rem; color:var(--text-muted); display:flex; align-items:center; gap:6px;">
            <input type="checkbox" name="escalate" value="1">
            Yetki sınırını aşan ihtilaflı durum — Üst Birime (Admin'e) Eskale Et (Senaryo 10)
          </label>
        </div>
      </form>
    </div>
  </main>
</div>
