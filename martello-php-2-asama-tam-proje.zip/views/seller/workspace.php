<?php
/** @var array $db */
/** @var callable $formatPrice */
$seller = $db['users'][1]['saticiProfili'];
?>
<div class="workspace-wrapper">
  <aside class="sidebar">
    <div class="sidebar-label">ÇALIŞMA ALANI (SATICI)</div>
    <ul class="side-nav">
      <li><a href="#genel-bakis" class="active">🏠 Genel bakış</a></li>
      <li><a href="#yeni-urun">➕ Yeni ürün ekle (FR-07)</a></li>
      <li><a href="#ilanlarim">📋 İlanlarım</a></li>
      <li><a href="#faturalar">🧾 Bakiye ve komisyon (FR-22)</a></li>
    </ul>
  </aside>

  <main class="main-content">
    <?php if (!empty($flashMessage)): ?>
      <div class="alert-box"><?= htmlspecialchars($flashMessage['message']) ?></div>
    <?php endif; ?>

    <div class="workspace-header">
      <div class="sub-kicker">SATICI / ÇALIŞMA ALANI</div>
      <h1>Genel bakış</h1>
      <p style="color:var(--text-muted);">Seçkin müzayede deneyiminizi yönetin</p>
    </div>

    <!-- SRS SAYFA 34 ÜST EKRAN KPI KARTLARI -->
    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">AKTİF İLANLAR</div>
        <div class="kpi-value"><?= count($db['listings']) ?></div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">TOPLAM SATIŞ</div>
        <div class="kpi-value" style="color:var(--gold-bright);"><?= $formatPrice((float)$seller['toplamSatisTutari']) ?></div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">TASLAKLAR</div>
        <div class="kpi-value"><?= (int)$seller['taslakSayisi'] ?></div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">TEKLİFLER</div>
        <div class="kpi-value"><?= (int)$seller['toplamTeklifSayisi'] ?></div>
      </div>
    </div>

    <div id="yeni-urun" class="panel-card">
      <h2>Satış performansı & Yeni ilan oluştur (FR-07, FR-31)</h2>
      <p style="color:var(--text-muted); margin-bottom:14px;">İlanlarınızı ve yeni teklifleri tek yerden yönetin. Zorunlu alan doğrulaması (FR-31) aktiftir.</p>
      <form method="POST">
        <input type="hidden" name="action" value="create_listing">
        <input type="hidden" name="seller_id" value="2">
        <div class="form-grid">
          <div>
            <label style="font-size:0.8rem; color:var(--text-muted);">Ürün / Lot Başlığı *</label>
            <input type="text" name="title" class="form-control" placeholder="Örn: 1890 Osmanlı Tuğralı Gümüş Kupa" required>
          </div>
          <div>
            <label style="font-size:0.8rem; color:var(--text-muted);">Kategori Şablonu (FR-08) *</label>
            <select name="category_id" class="form-control">
              <?php foreach ($db['categories'] as $c): ?>
                <option value="<?= (int)$c['id'] ?>"><?= htmlspecialchars($c['ad']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label style="font-size:0.8rem; color:var(--text-muted);">Başlangıç Fiyatı (TRY) *</label>
            <input type="number" name="start_price" value="25000" class="form-control" required>
          </div>
          <div>
            <label style="font-size:0.8rem; color:var(--text-muted);">Rezerv (Taban) Fiyat (FR-32) *</label>
            <input type="number" name="reserve_price" value="35000" class="form-control" required>
          </div>
        </div>
        <button type="submit" class="gold-btn" style="margin-top:14px;">Yeni ilan oluştur</button>
      </form>
    </div>

    <div id="faturalar" class="panel-card">
      <h3>Satılan Ürünler (Lot) ve Resmi Faturalar (Kullanıcı Hikayesi 12)</h3>
      <table class="martello-table">
        <thead>
          <tr>
            <th>Fatura No</th>
            <th>Sipariş ID</th>
            <th>Lot ID</th>
            <th>Toplam Tahsilat</th>
            <th>Platform Komisyonu</th>
            <th>Durum</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($db['invoices'] as $inv): ?>
            <tr>
              <td><strong><?= htmlspecialchars($inv['faturaNo']) ?></strong></td>
              <td>#<?= (int)$inv['siparisId'] ?></td>
              <td>#<?= (int)$inv['lotId'] ?></td>
              <td style="color:var(--gold-bright);"><?= $formatPrice((float)$inv['toplamTutar']) ?></td>
              <td><?= $formatPrice((float)$inv['komisyonTutari']) ?></td>
              <td><span class="badge badge-green"><?= htmlspecialchars($inv['durum']) ?></span></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
