<?php
// CBSE Modüler Arayüz Bileşeni: Emanet/Bloke Durum Gösterge Bileşeni (FR-23)
