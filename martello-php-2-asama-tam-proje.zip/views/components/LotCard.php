<?php
// CBSE Modüler Arayüz Bileşeni: Yeniden Kullanılabilir Lot Kartı Bileşeni (FR-11, FR-12)
