<?php
// CBSE Modüler Arayüz Bileşeni: Çoklu Para Birimi (TRY/USD/EUR) Seçici Bileşeni (FR-21)
