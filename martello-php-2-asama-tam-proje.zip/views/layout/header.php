<?php
/** @var string $activeRole */
/** @var string $activeCurrency */
/** @var string $currencySymbol */
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MARTELLO — Çevrimiçi Müzayede ve Ekspertiz Platformu</title>
  <link rel="stylesheet" href="public/assets/css/martello.css">
</head>
<body>
<header class="topbar">
  <a href="?role=vitrin" class="brand-logo">
    <span>MARTELLO</span>
    <span class="gavel">🔨</span>
  </a>

  <nav class="role-switcher">
    <a href="?role=vitrin&currency=<?= htmlspecialchars($activeCurrency) ?>" class="role-tab <?= $activeRole === 'vitrin' ? 'active' : '' ?>">Vitrin (Ana Sayfa)</a>
    <a href="?role=buyer&currency=<?= htmlspecialchars($activeCurrency) ?>" class="role-tab <?= $activeRole === 'buyer' ? 'active' : '' ?>">1. Alıcı Çalışma Alanı</a>
    <a href="?role=seller&currency=<?= htmlspecialchars($activeCurrency) ?>" class="role-tab <?= $activeRole === 'seller' ? 'active' : '' ?>">2. Satıcı Çalışma Alanı</a>
    <a href="?role=appraiser&currency=<?= htmlspecialchars($activeCurrency) ?>" class="role-tab <?= $activeRole === 'appraiser' ? 'active' : '' ?>">3. Ekspertiz Uzmanı</a>
    <a href="?role=support&currency=<?= htmlspecialchars($activeCurrency) ?>" class="role-tab <?= $activeRole === 'support' ? 'active' : '' ?>">4. Canlı Destek</a>
    <a href="?role=admin&currency=<?= htmlspecialchars($activeCurrency) ?>" class="role-tab <?= $activeRole === 'admin' ? 'active' : '' ?>">5. Admin Yönetim Konsolu</a>
  </nav>

  <div style="display:flex; align-items:center; gap:10px;">
    <span style="font-size:0.8rem; color:var(--text-muted);">Kur (FR-21):</span>
    <a href="?role=<?= htmlspecialchars($activeRole) ?>&currency=TRY" class="role-tab <?= $activeCurrency === 'TRY' ? 'active' : '' ?>">₺ TRY</a>
    <a href="?role=<?= htmlspecialchars($activeRole) ?>&currency=USD" class="role-tab <?= $activeCurrency === 'USD' ? 'active' : '' ?>">$ USD</a>
    <a href="?role=<?= htmlspecialchars($activeRole) ?>&currency=EUR" class="role-tab <?= $activeCurrency === 'EUR' ? 'active' : '' ?>">€ EUR</a>
  </div>
</header>
