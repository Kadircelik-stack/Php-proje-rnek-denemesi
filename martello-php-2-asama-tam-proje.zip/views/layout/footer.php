<footer style="border-top:1px solid var(--border-subtle); padding:24px 36px; margin-top:40px; display:flex; justify-content:space-between; color:var(--text-muted); font-size:0.82rem;">
  <div>
    <strong style="color:var(--gold-primary);">MARTELLO</strong> — Türkiye'nin seçkin koleksiyonlarına açılan kapı.<br>
    <span>ZeroDay Ekibi: Esra Yıldırım (2407231069) • Abdullah Kadir Çelik (2407231061) • Rümeysa Şevval Kandilci (2407231031)</span>
  </div>
  <div>
    <span>Katmanlı Mimari (CBSE + Observer & Strategy) • JSON Veri Deposu (ACID & LOCK_EX) • WORM Denetim İzi</span>
  </div>
</footer>
<script src="public/assets/js/martello-app.js"></script>
</body>
</html>
