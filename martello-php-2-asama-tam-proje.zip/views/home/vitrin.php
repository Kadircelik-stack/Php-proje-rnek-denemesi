<?php
/** @var array $db */
/** @var callable $formatPrice */
?>
<div style="padding:36px; max-width:1320px; margin:0 auto;">
  <div class="panel-card" style="background:linear-gradient(120deg, #1b1712 0%, #2a2218 100%); border-color:var(--gold-primary); padding:44px 40px;">
    <div style="font-size:0.78rem; letter-spacing:2px; text-transform:uppercase; color:var(--gold-primary); margin-bottom:10px;">
      MARTELLO — SEÇKİN KOLEKSİYONLAR
    </div>
    <h1 style="font-size:2.7rem; max-width:560px; line-height:1.2; margin-bottom:14px;">
      Saatler vardır, anıları hatırlatır.
    </h1>
    <p style="color:var(--text-muted); max-width:520px; margin-bottom:24px;">
      Bağımsız akredite ekspertiz uzmanlarınca incelenmiş seçkin koleksiyonları keşfedin, Emanet (Escrow) güvencesiyle canlı teklif verin.
    </p>
    <a href="?role=buyer" class="gold-btn">Müzayedeleri Keşfet ↗</a>
  </div>

  <div style="margin:28px 0 16px;">
    <div style="font-size:0.75rem; text-transform:uppercase; letter-spacing:1.5px; color:var(--gold-primary);">KOLEKSİYONLARI KEŞFEDİN (FR-08 & FR-11)</div>
    <h2 style="font-size:1.45rem; margin-top:4px;">Her parça bir hikâye.</h2>
  </div>

  <div class="kpi-grid">
    <?php foreach ($db['categories'] as $cat): ?>
      <div class="panel-card" style="margin-bottom:0;">
        <span class="badge badge-gold">Komisyon: %<?= htmlspecialchars((string)$cat['komisyonOraniYuzde']) ?></span>
        <h3 style="margin-top:12px; font-size:1.15rem;"><?= htmlspecialchars($cat['ad']) ?></h3>
        <p style="color:var(--text-muted); font-size:0.85rem; margin:8px 0 14px;"><?= htmlspecialchars($cat['aciklama'] ?? '') ?></p>
        <a href="?role=buyer" class="outline-btn">Lotları İncele</a>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="panel-card" style="margin-top:28px;">
    <h3>Aktif ve Canlı Müzayede Lotları (FR-12, FR-34, FR-35)</h3>
    <table class="martello-table" style="margin-top:12px;">
      <thead>
        <tr>
          <th>Lot Kodu</th>
          <th>Eser Başlığı</th>
          <th>Kategori</th>
          <th>Güncel En Yüksek Pey</th>
          <th>Lider (NFR-25 Maskeli)</th>
          <th>Kalan Süre (FR-35)</th>
          <th>İşlem</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($db['lots'] as $lot): ?>
          <tr>
            <td><strong><?= htmlspecialchars($lot['lotKodu']) ?></strong></td>
            <td><?= htmlspecialchars($lot['baslik']) ?></td>
            <td><?= htmlspecialchars($lot['kategoriAdi']) ?></td>
            <td style="color:var(--gold-bright); font-weight:600;"><?= $formatPrice((float)$lot['mevcutEnYuksekTeklif']) ?></td>
            <td><span class="badge badge-gold"><?= htmlspecialchars($lot['liderAnonimKod']) ?></span></td>
            <td>
              <?php if ($lot['durum'] === 'ACIK_ARTIRMADA'): ?>
                <span data-countdown-seconds="19380"><?= htmlspecialchars($lot['kalanSureMetni']) ?></span>
              <?php else: ?>
                <span class="badge badge-green"><?= htmlspecialchars($lot['durum']) ?></span>
              <?php endif; ?>
            </td>
            <td><a href="?role=buyer" class="gold-btn" style="padding:6px 14px; font-size:0.8rem;">Pey Ver</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
