<?php
/** @var array $db */
/** @var callable $formatPrice */
$featuredLot = $db['lots'][0]; // AUC-1642: 1968 İsviçre Vintage Saat
$report      = $db['appraisalReports'][0];
$buyerWallet = $db['wallets'][2]; // Kullanıcı #3 Cüzdanı
?>
<div class="workspace-wrapper">
  <aside class="sidebar">
    <div class="sidebar-label">ÇALIŞMA ALANI (ALICI)</div>
    <ul class="side-nav">
      <li><a href="#canli-muzayede" class="active">📡 Canlı müzayede (FR-12)</a></li>
      <li><a href="#kazanilan-lotlar">🏆 Kazanılan lotlar (FR-16)</a></li>
      <li><a href="#takip-edilenler">🤍 Takip edilenler (FR-36)</a></li>
      <li><a href="#bakiye-fatura">💳 Bakiye ve faturalar (FR-23)</a></li>
      <li><a href="#itirazlar">⚖️ İtirazlar (FR-20)</a></li>
    </ul>
  </aside>

  <main class="main-content">
    <?php if (!empty($flashMessage)): ?>
      <div class="alert-box"><?= htmlspecialchars($flashMessage['message']) ?></div>
    <?php endif; ?>

    <!-- ÜST BÖLÜM: SRS SAYFA 33 ÜST EKRAN (AUC-1642 1968 İsviçre Vintage Saat Canlı Müzayede) -->
    <div id="canli-muzayede" class="workspace-header">
      <div class="sub-kicker">LOT DETAYI • CANLI MÜZAYEDE VE EKSPERTİZ ONAYLI</div>
      <h1><?= htmlspecialchars($featuredLot['baslik']) ?> – Müzayede No: <?= htmlspecialchars($featuredLot['lotKodu']) ?></h1>
    </div>

    <div class="lot-detail-grid">
      <div>
        <div class="panel-card">
          <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:12px; margin-bottom:16px;">
            <div style="background:#12100d; border:1px solid var(--border-gold); border-radius:8px; padding:22px; text-align:center;">
              <div style="font-size:2.4rem;">⌚</div>
              <div style="font-size:0.78rem; color:var(--text-muted); margin-top:6px;">Kadran & Kronograf</div>
            </div>
            <div style="background:#12100d; border:1px solid var(--border-gold); border-radius:8px; padding:22px; text-align:center;">
              <div style="font-size:2.4rem;">⚙️</div>
              <div style="font-size:0.78rem; color:var(--text-muted); margin-top:6px;">Kalibre 861 Mekanizma</div>
            </div>
            <div style="background:#12100d; border:1px solid var(--border-gold); border-radius:8px; padding:22px; text-align:center;">
              <div style="font-size:2.4rem;">🛡️</div>
              <div style="font-size:0.78rem; color:var(--text-muted); margin-top:6px;">Orijinal Arka Kapak</div>
            </div>
          </div>
          <p style="color:var(--text-muted); font-size:0.92rem;">
            1968 İsviçre üretimi mekanik kronograf kol saati. Orijinal kadranı, kurma kolu ve kalibre mekanizması bağımsız ekspertiz heyetimiz tarafından fiziksel olarak incelenerek onaylanmıştır. Son 30 saniyede gelen tekliflerde <strong>Anti-Sniping (+30 sn / +10 sn - FR-33, NFR-23)</strong> kuralı otomatik devreye girer.
          </p>
        </div>

        <!-- EKSPERTİZ RAPORU KUTUSU (SRS Sayfa 33) -->
        <div class="appraisal-paper" style="margin-bottom:24px;">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <h3>Ekspertiz Raporu (<?= htmlspecialchars($report['raporNo']) ?>)</h3>
            <span class="stamp-seal">✓ Ekspertiz Seçki</span>
          </div>
          <ul style="padding-left:18px; font-size:0.9rem; margin-bottom:12px;">
            <?php foreach ($report['maddeler'] as $madde): ?>
              <li style="margin-bottom:4px;"><?= htmlspecialchars($madde) ?></li>
            <?php endforeach; ?>
          </ul>
          <div style="font-size:0.8rem; color:#5a4d3b; display:flex; justify-content:space-between;">
            <span><strong>Akredite Uzman:</strong> Burak Şahin (Marmara Ekspertiz A.Ş. - EXP-2024-889)</span>
            <span><strong>Önerilen Piyasa Değeri:</strong> <?= $formatPrice((float)$report['onerilenPiyasaDegeri']) ?></span>
          </div>
        </div>
      </div>

      <!-- SAĞ SÜTUN: CANLI PEY KUTUSU VE DİĞER TEKLİFLER (SRS Sayfa 33) -->
      <div>
        <div class="panel-card" style="border-color:var(--gold-primary);">
          <div style="font-size:0.8rem; color:var(--text-muted);">Güncel teklif (FR-34 &le;1 sn WebSocket)</div>
          <div style="font-size:2.2rem; font-weight:700; color:var(--gold-bright); margin:4px 0;">
            <?= $formatPrice((float)$featuredLot['mevcutEnYuksekTeklif']) ?>
          </div>
          <div style="font-size:0.88rem; color:var(--text-muted); margin-bottom:16px;">
            ⏳ Kalan Süre: <strong data-countdown-seconds="19380" style="color:var(--text-main);"><?= htmlspecialchars($featuredLot['kalanSureMetni']) ?></strong>
          </div>

          <form method="POST" style="margin-bottom:16px;">
            <input type="hidden" name="action" value="place_bid">
            <label style="font-size:0.8rem; color:var(--text-muted);">Lot Seçimi:</label>
            <select name="lot_id" class="form-control" style="margin-bottom:10px;">
              <?php foreach ($db['lots'] as $l): ?>
                <?php if ($l['durum'] === 'ACIK_ARTIRMADA'): ?>
                  <option value="<?= (int)$l['id'] ?>">
                    <?= htmlspecialchars($l['lotKodu'] . ' — ' . $l['baslik'] . ' (Min: ' . ($l['mevcutEnYuksekTeklif'] + $l['minimumArtisTutari']) . ' TRY)') ?>
                  </option>
                <?php endif; ?>
              <?php endforeach; ?>
            </select>
            <label style="font-size:0.8rem; color:var(--text-muted);">Teklif Veren Alıcı Hesabı:</label>
            <select name="buyer_id" class="form-control" style="margin-bottom:10px;">
              <option value="6">Emre K. (Anonim: damror0ki — Bakiye: 110.000 TL)</option>
              <option value="3">Zeynep D. (Anonim: yortunen... — Bakiye: 120.000 TL)</option>
            </select>
            <label style="font-size:0.8rem; color:var(--text-muted);">Teklif Tutarınız (TRY):</label>
            <input type="number" step="500" name="bid_amount" value="<?= (float)($featuredLot['mevcutEnYuksekTeklif'] + $featuredLot['minimumArtisTutari']) ?>" class="form-control" style="margin-bottom:12px;" required>
            <button type="submit" class="gold-btn" style="width:100%;">Pey Ver & Teminat Bloke Et (FR-13)</button>
          </form>

          <!-- OTOMATİK TEKLİF / PROXY BIDDING FORMU (Bölüm 2.6.1 & NFR-24) -->
          <form method="POST" style="border-top:1px solid var(--border-subtle); padding-top:14px;">
            <input type="hidden" name="action" value="set_proxy_bid">
            <input type="hidden" name="lot_id" value="1001">
            <input type="hidden" name="buyer_id" value="3">
            <div style="font-size:0.8rem; color:var(--gold-primary); margin-bottom:6px;">🤖 Otomatik Teklif / Proxy Bidding (NFR-24)</div>
            <div style="display:flex; gap:8px;">
              <input type="number" step="1000" name="max_budget" value="85000" class="form-control" placeholder="Maks. Bütçe (TRY)">
              <button type="submit" class="outline-btn">Kur</button>
            </div>
          </form>
        </div>

        <div class="panel-card">
          <h3 style="font-size:1rem;">Diğer Teklifler (FR-14 & NFR-25 Maskeli)</h3>
          <table class="martello-table">
            <tbody>
              <?php foreach (array_reverse($db['bids']) as $bid): ?>
                <tr>
                  <td><strong><?= htmlspecialchars($bid['aliciAnonimKod']) ?></strong></td>
                  <td style="color:var(--gold-bright);"><?= $formatPrice((float)$bid['teklifTutari']) ?></td>
                  <td style="font-size:0.78rem; color:var(--text-muted);"><?= htmlspecialchars($bid['saatEtiketi'] ?? '') ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ALT BÖLÜM: SRS SAYFA 33 ALT EKRAN (Kazanılan Lotlar Tablosu ve Ödeme Detayları) -->
    <div id="kazanilan-lotlar" class="panel-card" style="margin-top:12px;">
      <div class="sub-kicker">ALICI / ÇALIŞMA ALANI</div>
      <h2 style="font-size:1.6rem; margin-bottom:14px;">Kazanılan lotlar (FR-16 & FR-29)</h2>
      <table class="martello-table">
        <thead>
          <tr>
            <th>Lot</th>
            <th>Ürün</th>
            <th>Kategori</th>
            <th>Son Tarih</th>
            <th>Son Fiyat</th>
            <th>Komisyon (%8)</th>
            <th>Ödeme Durumu</th>
            <th>Kargo Takip</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($db['orders'] as $ord): ?>
            <tr>
              <td><strong><?= htmlspecialchars($ord['lotKodu']) ?></strong></td>
              <td><?= htmlspecialchars($ord['urunBaslik']) ?></td>
              <td><?= htmlspecialchars($ord['kategoriAdi']) ?></td>
              <td><?= htmlspecialchars($ord['sonTarih']) ?></td>
              <td style="color:var(--gold-bright); font-weight:600;"><?= $formatPrice((float)$ord['kapanisFiyati']) ?></td>
              <td><?= $formatPrice((float)$ord['komisyonTutari']) ?></td>
              <td><span class="badge badge-green"><?= htmlspecialchars($ord['siparisDurumu']) ?></span></td>
              <td><code><?= htmlspecialchars($ord['kargoTakipNo']) ?></code></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- BAKİYE YÜKLEME VE İHTİLAF TALEBİ (Kullanıcı Hikayesi 7 & 13) -->
    <div id="bakiye-fatura" style="display:grid; grid-template-columns:1fr 1fr; gap:24px;">
      <div class="panel-card">
        <h3>💳 Emanet (Escrow) Cüzdan & Bakiye Yükle (FR-23)</h3>
        <p style="color:var(--text-muted); font-size:0.88rem; margin-bottom:12px;">
          Kullanılabilir Bakiye: <strong style="color:var(--gold-bright);"><?= $formatPrice((float)$buyerWallet['bakiye']) ?></strong> |
          Emanet Bloke: <strong><?= $formatPrice((float)$buyerWallet['blokeBakiye']) ?></strong>
        </p>
        <form method="POST" style="display:flex; gap:10px;">
          <input type="hidden" name="action" value="topup_wallet">
          <input type="hidden" name="user_id" value="3">
          <input type="number" name="amount" value="25000" class="form-control">
          <button type="submit" class="gold-btn">Bakiye Yükle</button>
        </form>
      </div>

      <div id="itirazlar" class="panel-card">
        <h3>⚖️ İhtilaf / İtiraz Talebi Oluştur (FR-20)</h3>
        <form method="POST">
          <input type="hidden" name="action" value="create_dispute">
          <input type="hidden" name="user_id" value="3">
          <input type="hidden" name="lot_id" value="1001">
          <input type="text" name="description" class="form-control" placeholder="İtiraz gerekçenizi ve kanıt referansını yazın..." style="margin-bottom:10px;" required>
          <button type="submit" class="outline-btn">İhtilaf Kaydı Aç</button>
        </form>
      </div>
    </div>
  </main>
</div>
