<?php
/** @var array $db */
/** @var callable $formatPrice */
?>
<div class="workspace-wrapper">
  <aside class="sidebar">
    <div class="sidebar-label">ÇALIŞMA ALANI (ADMİN)</div>
    <ul class="side-nav">
      <li><a href="#yonetim-konsolu" class="active">🛡️ Yönetim konsolu</a></li>
      <li><a href="#kullanicilar">👥 Kullanıcılar (FR-04, FR-06)</a></li>
      <li><a href="#muzayede-kontrol">🔨 Müzayede Başlat/Bitir (FR-10)</a></li>
      <li><a href="#denetim-izi">🔒 Denetim izi (WORM - FR-25)</a></li>
    </ul>
  </aside>

  <main class="main-content">
    <?php if (!empty($flashMessage)): ?>
      <div class="alert-box"><?= htmlspecialchars($flashMessage['message']) ?></div>
    <?php endif; ?>

    <div id="yonetim-konsolu" class="workspace-header">
      <div class="sub-kicker">ADMİN / ÇALIŞMA ALANI (FIDO2 DONANIM MFA DOĞRULANDI - NFR-18)</div>
      <h1>Yönetim konsolu</h1>
      <p style="color:var(--text-muted);">Moderasyon, ekspertiz, komisyon ve WORM denetim izi akışlarını yönetin.</p>
    </div>

    <!-- SRS SAYFA 34 ALT EKRAN KPI KARTLARI -->
    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">KULLANICILAR</div>
        <div class="kpi-value"><?= count($db['users']) ?></div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">AKTİF LOTLAR</div>
        <div class="kpi-value"><?= count($db['lots']) ?></div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">RAPORLAR</div>
        <div class="kpi-value"><?= count($db['appraisalReports']) ?></div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">AÇIK İHTİLAFLAR</div>
        <div class="kpi-value"><?= count($db['disputes']) ?></div>
      </div>
    </div>

    <div id="kullanicilar" class="panel-card">
      <h3>Kullanıcı Yönetimi, KYC Doğrulama ve Hesap Askıya Alma / Ban (FR-04, FR-05, FR-06)</h3>
      <table class="martello-table" style="margin-top:10px;">
        <thead>
          <tr>
            <th>ID</th>
            <th>Ad Soyad</th>
            <th>Rol</th>
            <th>Anonim Kod (NFR-25)</th>
            <th>KYC (AES-256)</th>
            <th>Durum</th>
            <th>Yaptırım (FR-06)</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($db['users'] as $u): ?>
            <tr>
              <td>#<?= (int)$u['id'] ?></td>
              <td><strong><?= htmlspecialchars($u['ad'] . ' ' . $u['soyad']) ?></strong></td>
              <td><span class="badge badge-gold"><?= htmlspecialchars($u['rol']) ?></span></td>
              <td><code><?= htmlspecialchars($u['anonimKod']) ?></code></td>
              <td><span class="badge badge-green">Doğrulandı</span></td>
              <td>
                <span class="badge <?= $u['durum'] === 'AKTIF' ? 'badge-green' : 'badge-red' ?>">
                  <?= htmlspecialchars($u['durum']) ?>
                </span>
              </td>
              <td>
                <?php if ($u['rol'] !== 'ADMIN'): ?>
                  <form method="POST" style="display:inline;">
                    <input type="hidden" name="action" value="toggle_ban">
                    <input type="hidden" name="target_user_id" value="<?= (int)$u['id'] ?>">
                    <input type="hidden" name="new_status" value="<?= $u['durum'] === 'AKTIF' ? 'ASKIYA_ALINDI' : 'AKTIF' ?>">
                    <button type="submit" class="outline-btn" style="padding:4px 10px; font-size:0.75rem;">
                      <?= $u['durum'] === 'AKTIF' ? 'Askıya Al / Banla' : 'Aktifleştir' ?>
                    </button>
                  </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div id="muzayede-kontrol" class="panel-card">
      <h3>Müzayede Sonlandırma ve Otomatik Sipariş Tetikleme (FR-10, FR-29)</h3>
      <form method="POST" style="display:flex; gap:12px; align-items:center; margin-top:10px;">
        <input type="hidden" name="action" value="close_lot">
        <select name="lot_id" class="form-control" style="max-width:420px;">
          <?php foreach ($db['lots'] as $l): ?>
            <option value="<?= (int)$l['id'] ?>"><?= htmlspecialchars($l['lotKodu'] . ' — ' . $l['baslik'] . ' (' . $l['durum'] . ')') ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit" class="gold-btn">Müzayedeyi Sonlandır & Otomatik Sipariş Oluştur</button>
      </form>
    </div>

    <div id="denetim-izi" class="panel-card">
      <h3>Değiştirilemez (WORM / Hash-Chained) Denetim İzi Günlüğü (FR-25, NFR-11, R-12)</h3>
      <table class="martello-table" style="margin-top:10px;">
        <thead>
          <tr>
            <th>Log ID</th>
            <th>Zaman Damgası</th>
            <th>Kullanıcı / Rol</th>
            <th>IP Adresi</th>
            <th>İşlem Tipi</th>
            <th>Shill Bidding (R-04)</th>
            <th>SHA-256 Zincir Özeti (Hash)</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach (array_reverse($db['auditLogs']) as $log): ?>
            <tr>
              <td><code><?= htmlspecialchars($log['logId']) ?></code></td>
              <td style="font-size:0.8rem;"><?= htmlspecialchars($log['zamanDamgasi']) ?></td>
              <td>#<?= (int)$log['kullaniciId'] ?> (<?= htmlspecialchars($log['kullaniciRol']) ?>)</td>
              <td><code><?= htmlspecialchars($log['ipAdresi']) ?></code></td>
              <td><?= htmlspecialchars($log['islemTipi']) ?></td>
              <td><span class="badge badge-green"><?= htmlspecialchars($log['shillBiddingDurumu']) ?></span></td>
              <td><code style="font-size:0.75rem; color:var(--gold-primary);"><?= htmlspecialchars(substr($log['currentHash'], 0, 20)) ?>...</code></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
